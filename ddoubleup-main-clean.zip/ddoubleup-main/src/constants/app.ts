// App constants
export const APP_NAME = "DoubleUp";
export const APP_VERSION = "1.0.0";
export const APP_TAGLINE = "Because dating is better with backup.";

// UI Constants
export const ANIMATION_DURATION = 0.35;
export const CARD_SWIPE_THRESHOLD = 100;
export const INTERESTS_MAX_SELECT = 6;
export const TRUNCATE_LENGTH = 100;

// Validation
export const PASSWORD_MIN_LENGTH = 8;
export const MIN_SEARCH_LENGTH = 2;

// Route paths
export const ROUTES = {
  HOME: "/",
  ONBOARDING: "/onboarding",
  SIGNUP: "/signup",
  LOGIN: "/login",
  SETUP_PROFILE: "/setup-profile",
  INVITE_FRIEND: "/invite-friend",
  DISCOVER: "/discover",
  VENUES: "/venues",
  CHATS: "/chats",
  CHAT_DETAIL: "/chat/:roomId",
  DUO_PROFILE: "/duo",
  PROFILE: "/profile",
  NOT_FOUND: "*",
} as const;

// Error messages
export const ERROR_MESSAGES = {
  SOMETHING_WRONG: "Something went wrong",
  UNEXPECTED_ERROR: "An unexpected error occurred. Please try again or contact support if the problem persists.",
  ENTER_EMAIL: "Enter your email",
  INVALID_EMAIL: "Please enter a valid email address",
  EMAIL_REQUIRED: ".edu email required",
  LOGIN_FAILED: "Login failed",
  NETWORK_ERROR: "Network error. Please check your connection.",
  UNSUPPORTED_FILE: "File type not supported. Please use JPG or PNG.",
  FILE_TOO_LARGE: "File is too large. Max 5MB.",
} as const;

// Success messages
export const SUCCESS_MESSAGES = {
  PASSWORD_RESET_SENT: "Check your email - we sent a password reset link to your inbox.",
  PROFILE_UPDATED: "Profile updated successfully",
  PHOTO_UPLOADED: "Photo uploaded successfully",
  BOOKING_CONFIRMED: "Booking confirmed!",
} as const;

// Interest options
export const INTERESTS_OPTIONS = [
  "Music", "Food", "Nightlife", "Sports", "Travel", "Art",
  "Greek Life", "Fitness", "Gaming", "Film", "Fashion", "Outdoors",
  "Photography", "Cooking", "Reading", "Coffee",
] as const;

// Chat themes
export const CHAT_THEMES = [
  { id: "default", label: "Default", bg: "bg-background", selfBubble: "bg-foreground text-background", otherBubble: "bg-muted text-foreground border border-border" },
  { id: "midnight", label: "Midnight", bg: "bg-[hsl(230,25%,12%)]", selfBubble: "bg-[hsl(260,60%,55%)] text-white", otherBubble: "bg-[hsl(230,20%,20%)] text-white border-none" },
  { id: "sunset", label: "Sunset", bg: "bg-[hsl(25,80%,95%)]", selfBubble: "bg-[hsl(15,80%,55%)] text-white", otherBubble: "bg-[hsl(30,60%,88%)] text-[hsl(15,50%,25%)] border-none" },
  { id: "ocean", label: "Ocean", bg: "bg-[hsl(200,40%,95%)]", selfBubble: "bg-[hsl(200,70%,45%)] text-white", otherBubble: "bg-[hsl(200,30%,88%)] text-[hsl(200,50%,20%)] border-none" },
  { id: "forest", label: "Forest", bg: "bg-[hsl(140,20%,94%)]", selfBubble: "bg-[hsl(150,50%,35%)] text-white", otherBubble: "bg-[hsl(140,20%,86%)] text-[hsl(150,30%,20%)] border-none" },
  { id: "rose", label: "Rosé", bg: "bg-[hsl(340,30%,95%)]", selfBubble: "bg-[hsl(340,60%,55%)] text-white", otherBubble: "bg-[hsl(340,25%,88%)] text-[hsl(340,40%,25%)] border-none" },
] as const;

// Universities (sample - should be expanded)
export const UNIVERSITIES = [
  "Arizona State University", "Boston College", "Boston University", "Brown University",
  "California Institute of Technology", "Carnegie Mellon University", "Clemson University",
  "Columbia University", "Cornell University", "Dartmouth College", "Duke University",
  "Emory University", "Florida Atlantic University", "Florida International University",
  "Florida State University", "Fordham University", "George Washington University",
  "Georgetown University", "Georgia Institute of Technology", "Gonzaga University",
  "Harvard University", "Howard University", "Indiana University Bloomington",
  "Iowa State University", "Johns Hopkins University", "Lehigh University",
  "Louisiana State University", "Loyola Marymount University", "Marquette University",
  "Massachusetts Institute of Technology", "Miami University (Ohio)", "Michigan State University",
  "New York University", "Northeastern University", "Northwestern University",
  "Ohio State University", "Oklahoma State University", "Oregon State University",
  "Pennsylvania State University", "Pepperdine University", "Princeton University",
  "Providence College", "Purdue University", "Rice University", "Rutgers University",
  "San Diego State University", "Santa Clara University", "Seton Hall University",
  "Southern Methodist University", "Stanford University", "Stony Brook University",
  "Syracuse University", "Temple University", "Texas A&M University",
  "Texas Christian University", "Tufts University", "Tulane University",
  "University of Alabama", "University of Arizona", "University of California, Berkeley",
  "University of California, Davis", "University of California, Irvine",
  "University of California, Los Angeles", "University of California, San Diego",
  "University of California, Santa Barbara", "University of California, Santa Cruz",
  "University of Chicago", "University of Cincinnati", "University of Colorado Boulder",
  "University of Connecticut", "University of Delaware", "University of Denver",
  "University of Florida", "University of Georgia", "University of Houston",
  "University of Illinois Urbana-Champaign", "University of Iowa", "University of Kansas",
  "University of Kentucky", "University of Maryland", "University of Massachusetts Amherst",
  "University of Miami", "University of Michigan", "University of Minnesota",
  "University of Mississippi", "University of Missouri", "University of Nebraska-Lincoln",
  "University of North Carolina at Chapel Hill", "University of Notre Dame",
  "University of Oklahoma", "University of Oregon", "University of Pennsylvania",
  "University of Pittsburgh", "University of Richmond", "University of Rochester",
  "University of San Diego", "University of South Carolina", "University of Southern California",
  "University of Tampa", "University of Tennessee", "University of Texas at Austin",
  "University of Vermont", "University of Virginia", "University of Washington",
  "University of Wisconsin-Madison", "Vanderbilt University", "Villanova University",
  "Virginia Tech", "Wake Forest University", "Washington State University",
  "Washington University in St. Louis", "West Virginia University", "Xavier University",
  "Yale University", "Other",
] as const;
