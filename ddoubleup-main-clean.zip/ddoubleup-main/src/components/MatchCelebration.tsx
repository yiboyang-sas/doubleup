import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface MatchCelebrationProps {
  show: boolean;
  onClose: () => void;
  matchNames: string;
  matchImages: [string, string];
  userPhoto?: string;
  roomId?: string;
}

const confettiColors = [
  "hsl(0, 0%, 8%)",
  "hsl(0, 0%, 25%)",
  "hsl(0, 0%, 45%)",
  "hsl(340, 60%, 55%)",
  "hsl(45, 90%, 55%)",
  "hsl(200, 70%, 50%)",
];

interface ConfettiPiece {
  id: number;
  x: number;
  delay: number;
  duration: number;
  color: string;
  size: number;
  rotation: number;
  shape: "square" | "circle" | "strip";
}

const generateConfetti = (count: number): ConfettiPiece[] =>
  Array.from({ length: count }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    delay: Math.random() * 0.8,
    duration: 1.5 + Math.random() * 2,
    color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
    size: 4 + Math.random() * 8,
    rotation: Math.random() * 720 - 360,
    shape: (["square", "circle", "strip"] as const)[Math.floor(Math.random() * 3)],
  }));

const MatchCelebration = ({ show, onClose, matchNames, matchImages, userPhoto, roomId }: MatchCelebrationProps) => {
  const navigate = useNavigate();
  const [confetti, setConfetti] = useState<ConfettiPiece[]>([]);

  useEffect(() => {
    if (show) {
      setConfetti(generateConfetti(60));
    }
  }, [show]);

  const defaultUserPhoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop";

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center"
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-foreground/60 backdrop-blur-sm" />

          {/* Confetti */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {confetti.map((piece) => (
              <motion.div
                key={piece.id}
                initial={{ y: -20, x: `${piece.x}vw`, opacity: 1, rotate: 0, scale: 1 }}
                animate={{
                  y: "110vh",
                  rotate: piece.rotation,
                  opacity: [1, 1, 0.8, 0],
                  scale: [1, 1.2, 0.8],
                }}
                transition={{
                  duration: piece.duration,
                  delay: piece.delay,
                  ease: "easeIn",
                }}
                className="absolute top-0"
                style={{
                  width: piece.shape === "strip" ? piece.size * 0.4 : piece.size,
                  height: piece.shape === "strip" ? piece.size * 2.5 : piece.size,
                  backgroundColor: piece.color,
                  borderRadius: piece.shape === "circle" ? "50%" : piece.shape === "strip" ? "2px" : "1px",
                }}
              />
            ))}
          </div>

          {/* Content */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", damping: 15, stiffness: 200, delay: 0.2 }}
            className="relative z-10 w-full max-w-sm mx-8"
          >
            <div className="bg-background rounded-3xl p-8 border border-border text-center">
              {/* Close */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-muted flex items-center justify-center"
              >
                <X size={14} className="text-muted-foreground" />
              </button>

              {/* Hearts animation */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.4, damping: 10 }}
                className="flex justify-center mb-4"
              >
                <div className="relative">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <Heart size={48} className="text-foreground" fill="currentColor" />
                  </motion.div>
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{
                        scale: [0, 1, 0],
                        opacity: [0, 0.6, 0],
                        x: [0, (i - 1) * 40],
                        y: [0, -20 - i * 10],
                      }}
                      transition={{ delay: 0.6 + i * 0.15, duration: 1.2, repeat: Infinity, repeatDelay: 1 }}
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                    >
                      <Heart size={16} className="text-muted-foreground" fill="currentColor" />
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Title */}
              <motion.h2
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-2xl font-bold font-display text-foreground mb-1"
              >
                It's a Match!
              </motion.h2>
              <motion.p
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="text-muted-foreground text-sm mb-6"
              >
                You and {matchNames} liked each other
              </motion.p>

              {/* Avatars */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="flex justify-center items-center gap-3 mb-8"
              >
                <div className="flex -space-x-3">
                  <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-primary">
                    <img src={userPhoto || defaultUserPhoto} alt="" className="w-full h-full rounded-full object-cover" />
                  </div>
                  <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-primary">
                    <img src={userPhoto || defaultUserPhoto} alt="" className="w-full h-full rounded-full object-cover" />
                  </div>
                </div>
                <Heart size={20} className="text-foreground mx-1" fill="currentColor" />
                <div className="flex -space-x-3">
                  <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-primary">
                    <img src={matchImages[0]} alt="" className="w-full h-full rounded-full object-cover" />
                  </div>
                  <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-primary">
                    <img src={matchImages[1]} alt="" className="w-full h-full rounded-full object-cover" />
                  </div>
                </div>
              </motion.div>

              {/* Buttons */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="space-y-3"
              >
                <button
                  onClick={() => { onClose(); navigate(roomId ? `/chat/${roomId}` : "/chats"); }}
                  className="w-full py-4 rounded-2xl bg-foreground text-background font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform glow-sm"
                >
                  <MessageCircle size={18} />
                  Start Chatting
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-3 rounded-2xl border border-border text-foreground font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Keep Swiping
                </button>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MatchCelebration;
