import React from "react";
import { cn } from "@/lib/utils";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", loading, children, disabled, ...props }, ref) => {
    const baseStyles = "font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 rounded-lg flex items-center justify-center gap-2";

    const variants = {
      primary: "bg-gradient-primary text-primary-foreground hover:opacity-90 active:scale-[0.98] focus-visible:outline-primary-foreground",
      secondary: "bg-muted text-foreground border border-border hover:bg-muted/80 active:scale-[0.98] focus-visible:outline-primary",
      ghost: "text-foreground hover:bg-muted/30 active:scale-[0.98] focus-visible:outline-primary",
      destructive: "bg-destructive text-destructive-foreground hover:opacity-90 active:scale-[0.98] focus-visible:outline-destructive",
    };

    const sizes = {
      sm: "px-3 py-1.5 text-sm",
      md: "px-4 py-2.5 text-base",
      lg: "px-6 py-3.5 text-lg",
    };

    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          baseStyles,
          variants[variant],
          sizes[size],
          (disabled || loading) && "opacity-50 cursor-not-allowed hover:opacity-50"
        )}
        {...props}
      >
        {loading && <span className="animate-spin">⟳</span>}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => (
    <div className="w-full">
      {label && (
        <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">
          {label}
        </label>
      )}
      <input
        ref={ref}
        className={cn(
          "w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all",
          error && "border-destructive focus:ring-destructive/20",
          className
        )}
        {...props}
      />
      {error && <p className="text-xs text-destructive mt-1.5">{error}</p>}
    </div>
  )
);

Input.displayName = "Input";

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hoverable?: boolean;
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, hoverable, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "rounded-2xl border border-border bg-card p-4",
        hoverable && "hover:border-foreground/30 hover:bg-muted/30 transition-all",
        className
      )}
      {...props}
    />
  )
);

Card.displayName = "Card";

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "primary" | "secondary" | "destructive";
}

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant = "primary", ...props }, ref) => {
    const variants = {
      primary: "bg-foreground/10 text-foreground",
      secondary: "bg-muted/50 text-muted-foreground",
      destructive: "bg-destructive/10 text-destructive",
    };

    return (
      <span
        ref={ref}
        className={cn(
          "inline-block px-2.5 py-0.5 rounded-full text-xs font-medium",
          variants[variant],
          className
        )}
        {...props}
      />
    );
  }
);

Badge.displayName = "Badge";

interface SpinnerProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ size = "md", className }) => {
  const sizes = {
    sm: "w-4 h-4",
    md: "w-8 h-8",
    lg: "w-12 h-12",
  };

  return (
    <div className={cn("animate-spin rounded-full border-2 border-muted border-t-foreground", sizes[size], className)} />
  );
};

Spinner.displayName = "Spinner";
