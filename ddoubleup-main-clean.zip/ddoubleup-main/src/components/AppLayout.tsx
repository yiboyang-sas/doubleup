import { Outlet } from "react-router-dom";

const AppLayout = () => {
  return (
    <div className="iphone-frame bg-background">
      <Outlet />
    </div>
  );
};

export default AppLayout;
