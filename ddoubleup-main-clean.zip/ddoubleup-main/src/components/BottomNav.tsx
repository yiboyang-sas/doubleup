import { useLocation, useNavigate } from "react-router-dom";
import { MapPin, MessageCircle, User, Compass, Sparkles } from "lucide-react";

const tabs = [
  { path: "/discover", icon: Compass, label: "Discover" },
  { path: "/venues", icon: MapPin, label: "Venues" },
  { path: "/chats", icon: MessageCircle, label: "Chat" },
  { path: "/duo", icon: Sparkles, label: "Duo" },
  { path: "/profile", icon: User, label: "Profile" },
];

const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] glass safe-bottom z-50">
      <div className="flex items-center justify-around px-2 pt-2 pb-1">
        {tabs.map(({ path, icon: Icon, label }) => {
          const active = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className="flex flex-col items-center gap-0.5 px-3 py-1 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary rounded-lg"
              aria-label={`Navigate to ${label}`}
              aria-current={active ? "page" : undefined}
            >
              <Icon
                size={22}
                className={active ? "text-primary" : "text-muted-foreground"}
                strokeWidth={active ? 2.5 : 1.5}
              />
              <span
                className={`text-[10px] font-medium ${
                  active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {label}
              </span>
              {active && (
                <div className="w-1 h-1 rounded-full bg-primary mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;
