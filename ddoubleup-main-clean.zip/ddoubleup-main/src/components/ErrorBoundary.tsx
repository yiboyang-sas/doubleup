import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-dvh flex flex-col items-center justify-center px-8 text-center bg-background">
          <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
            <div className="text-4xl">⚠️</div>
          </div>
          <h1 className="text-2xl font-bold font-display text-foreground mb-2">Something went wrong</h1>
          <p className="text-muted-foreground mb-8 max-w-sm">An unexpected error occurred. Please try again or contact support if the problem persists.</p>
          <div className="flex flex-col gap-3 w-full max-w-xs">
            <button
              onClick={() => { this.setState({ hasError: false }); window.location.href = "/"; }}
              className="px-6 py-3 rounded-2xl bg-foreground text-background font-semibold active:scale-[0.98] hover:opacity-90 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground"
            >
              Go Home
            </button>
            <button
              onClick={() => { this.setState({ hasError: false }); }}
              className="px-6 py-3 rounded-2xl border border-border text-foreground font-semibold active:scale-[0.98] hover:bg-muted transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
