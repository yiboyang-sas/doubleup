// Type definitions for the app
export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface Profile {
  id: string;
  user_id: string;
  display_name: string | null;
  email: string | null;
  university: string | null;
  interested_in: "men" | "women" | "everyone" | null;
  bio: string | null;
  avatar_url: string | null;
  instagram: string | null;
  tiktok: string | null;
  interests: string[] | null;
  created_at: string;
  updated_at: string;
}

export interface Duo {
  id: string;
  user1_id: string;
  user2_id: string;
  prompt1: string;
  answer1: string;
  prompt2: string;
  answer2: string;
  interests: string[];
  photo1_url: string;
  photo2_url: string;
  school: string;
  active: boolean;
  created_at: string;
}

export interface Match {
  id: string;
  user_id: string;
  liked_duo_id: string;
  status: "pending" | "matched" | "rejected";
  created_at: string;
}

export interface ChatRoom {
  id: string;
  name: string | null;
  type: "direct" | "group";
  created_at: string;
}

export interface ChatRoomMember {
  id: string;
  room_id: string;
  user_id: string;
  joined_at: string;
}

export interface Message {
  id: string;
  room_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface BlockedUser {
  id: string;
  user_id: string;
  blocked_user_id: string;
  created_at: string;
}

// API Response types
export interface ApiResponse<T> {
  data: T | null;
  error: ApiError | null;
  status: number;
}

export interface ApiError {
  message: string;
  code: string;
  details?: Record<string, any>;
}

// Form types
export interface SignUpFormData {
  email: string;
  password: string;
  displayName: string;
  university: string;
  interestedIn: string;
}

export interface LoginFormData {
  email: string;
  password: string;
}

export interface ProfileUpdateData {
  displayName?: string;
  bio?: string;
  university?: string;
  interestedIn?: string;
  interests?: string[];
  instagram?: string;
  tiktok?: string;
  avatar_url?: string;
}

// UI types
export type ButtonVariant = "primary" | "secondary" | "ghost" | "destructive";
export type ButtonSize = "sm" | "md" | "lg";
export type BadgeVariant = "primary" | "secondary" | "destructive";

export interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: "default" | "destructive";
  open?: boolean;
}
