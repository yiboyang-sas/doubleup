import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import ErrorBoundary from "@/components/ErrorBoundary";
import Splash from "./pages/Splash";
import Onboarding from "./pages/Onboarding";
import SignUp from "./pages/SignUp";
import Login from "./pages/Login";
import SetupProfile from "./pages/SetupProfile";
import InviteFriend from "./pages/InviteFriend";
import Discover from "./pages/Discover";
import ChatList from "./pages/ChatList";
import Chat from "./pages/Chat";
import DuoProfile from "./pages/DuoProfile";
import Profile from "./pages/Profile";
import Venues from "./pages/Venues";
import NotFound from "./pages/NotFound";
import { useNotifications } from "@/hooks/useNotifications";

const queryClient = new QueryClient();

const NotificationListener = () => {
  useNotifications();
  return null;
};

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <NotificationListener />
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <div className="iphone-frame">
              <Routes>
                {/* Public routes */}
                <Route path="/" element={<Splash />} />
                <Route path="/onboarding" element={<Onboarding />} />
                <Route path="/signup" element={<SignUp />} />
                <Route path="/login" element={<Login />} />

                {/* Protected routes */}
                <Route path="/setup-profile" element={<ProtectedRoute><SetupProfile /></ProtectedRoute>} />
                <Route path="/invite-friend" element={<ProtectedRoute><InviteFriend /></ProtectedRoute>} />
                <Route path="/discover" element={<ProtectedRoute><Discover /></ProtectedRoute>} />
                <Route path="/venues" element={<ProtectedRoute><Venues /></ProtectedRoute>} />
                <Route path="/chats" element={<ProtectedRoute><ChatList /></ProtectedRoute>} />
                <Route path="/chat/:roomId" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
                <Route path="/duo" element={<ProtectedRoute><DuoProfile /></ProtectedRoute>} />
                <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

                <Route path="*" element={<NotFound />} />
              </Routes>
            </div>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
