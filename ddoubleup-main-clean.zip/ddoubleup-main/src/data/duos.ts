export interface Duo {
  id: number;
  names: string;
  school: string;
  age: string;
  prompt: string;
  answer: string;
  interests: string[];
  img1: string;
  img2: string;
  gender: "women" | "men";
}

export const allDuos: Duo[] = [
  // Harvard University
  { id: 1, names: "Mia & Jade", school: "Harvard University", age: "20 & 21", prompt: "Our ideal double date", answer: "Rooftop bar → late night pizza → walk by the Charles 🌙", interests: ["Nightlife", "Art", "Food"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },
  { id: 2, names: "Sophie & Emma", school: "Harvard University", age: "19 & 20", prompt: "Our vibe", answer: "Study hard, party harder. Looking for adventure partners 🏔️", interests: ["Outdoors", "Music", "Travel"], img1: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=400&h=600&fit=crop", gender: "women" },
  { id: 3, names: "Luna & Priya", school: "Harvard University", age: "21 & 21", prompt: "What we're looking for", answer: "Someone who can keep up with us on the dance floor 💃", interests: ["Greek Life", "Fitness", "Fashion"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },
  { id: 4, names: "Aria & Nora", school: "Harvard University", age: "20 & 20", prompt: "Friday night looks like", answer: "Harvard Square dinner → improv show → late night at Berk 🎭", interests: ["Art", "Food", "Film"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?w=400&h=600&fit=crop", gender: "women" },
  { id: 50, names: "Marcus & Tyler", school: "Harvard University", age: "21 & 22", prompt: "Our move", answer: "Pick you up, drive to the coast, surprise beach picnic 🏖️", interests: ["Outdoors", "Food", "Travel"], img1: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?w=400&h=600&fit=crop", gender: "men" },
  { id: 51, names: "James & Ethan", school: "Harvard University", age: "20 & 21", prompt: "Our energy", answer: "Varsity athletes by day, chefs by night 🍳", interests: ["Sports", "Food", "Fitness"], img1: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=600&fit=crop", gender: "men" },

  // Brown University
  { id: 5, names: "Zoe & Ivy", school: "Brown University", age: "20 & 21", prompt: "Our ideal double date", answer: "Thayer Street eats → sunset on the Green → vinyl shopping 🎶", interests: ["Music", "Food", "Art"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },
  { id: 6, names: "Ella & Sienna", school: "Brown University", age: "19 & 20", prompt: "What makes us fun", answer: "We'll turn any boring night into the best night ever ✨", interests: ["Nightlife", "Music", "Travel"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },
  { id: 52, names: "Noah & Liam", school: "Brown University", age: "21 & 20", prompt: "Our vibe", answer: "Art house cinema → late night diner debates 🎬", interests: ["Film", "Art", "Food"], img1: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=600&fit=crop", gender: "men" },

  // NYU
  { id: 7, names: "Ava & Chloe", school: "New York University", age: "20 & 20", prompt: "Friday night looks like", answer: "Gallery openings, rooftop cocktails, and deep convos until 3 AM 🍸", interests: ["Art", "Nightlife", "Fashion"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },
  { id: 8, names: "Naomi & Iris", school: "New York University", age: "20 & 21", prompt: "The way to our hearts", answer: "Good coffee, museum dates, and someone who reads for fun 📚", interests: ["Art", "Food", "Film"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },
  { id: 53, names: "Kai & Devon", school: "New York University", age: "20 & 21", prompt: "Date night", answer: "Speakeasy → jazz club → late walk through Washington Square 🌃", interests: ["Music", "Nightlife", "Art"], img1: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=400&h=600&fit=crop", gender: "men" },

  // Stanford
  { id: 9, names: "Taylor & Zoe", school: "Stanford University", age: "21 & 22", prompt: "Our weekend plans", answer: "Farmers market → beach in the afternoon → bonfire at night 🔥", interests: ["Outdoors", "Food", "Travel"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },
  { id: 10, names: "Maya & Layla", school: "Stanford University", age: "20 & 20", prompt: "Our type", answer: "Ambitious, funny, and down for spontaneous road trips 🚗", interests: ["Travel", "Fitness", "Music"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },
  { id: 54, names: "Ryan & Cole", school: "Stanford University", age: "21 & 21", prompt: "Perfect day", answer: "Morning surf → tacos → sunset hike at Dish 🏄", interests: ["Outdoors", "Sports", "Food"], img1: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1534030347209-467a5b0ad3e6?w=400&h=600&fit=crop", gender: "men" },

  // Columbia
  { id: 11, names: "Stella & Ruby", school: "Columbia University", age: "20 & 21", prompt: "Our energy", answer: "Main character energy with intellectual depth 💫", interests: ["Fashion", "Art", "Nightlife"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },
  { id: 55, names: "Alex & Jordan", school: "Columbia University", age: "21 & 22", prompt: "Our thing", answer: "Debate nerds who know every bar in Morningside Heights 🍻", interests: ["Nightlife", "Music", "Sports"], img1: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=600&fit=crop", gender: "men" },

  // UCLA
  { id: 12, names: "Hana & Mei", school: "University of California, Los Angeles", age: "21 & 21", prompt: "Double date dream", answer: "Sushi omakase → karaoke → night market 🎤", interests: ["Food", "Music", "Travel"], img1: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=400&h=600&fit=crop", gender: "women" },
  { id: 56, names: "Jayden & Mason", school: "University of California, Los Angeles", age: "20 & 21", prompt: "Weekend vibes", answer: "Beach volleyball → Diddy Riese → night out in Westwood 🏐", interests: ["Sports", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?w=400&h=600&fit=crop", gender: "men" },

  // Duke
  { id: 14, names: "Grace & Lily", school: "Duke University", age: "19 & 20", prompt: "We're the type to", answer: "Show up with a charcuterie board and a fire playlist 🧀🎶", interests: ["Food", "Music", "Outdoors"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },
  { id: 57, names: "Will & Chase", school: "Duke University", age: "20 & 21", prompt: "Game day", answer: "Cameron Crazies front row → cookout → late night at Shooters 🏀", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=600&fit=crop", gender: "men" },

  // Michigan
  { id: 15, names: "Riley & Jordan", school: "University of Michigan", age: "19 & 20", prompt: "We're looking for", answer: "A duo that loves tailgates, road trips, and good music 🎵", interests: ["Sports", "Music", "Greek Life"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },
  { id: 58, names: "Brett & Kyle", school: "University of Michigan", age: "21 & 21", prompt: "Saturdays in Ann Arbor", answer: "Big House tailgate → State Street → Cottage Inn 🏈", interests: ["Sports", "Greek Life", "Food"], img1: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=400&h=600&fit=crop", gender: "men" },

  // USC
  { id: 16, names: "Bella & Camila", school: "University of Southern California", age: "20 & 20", prompt: "Our energy", answer: "Main character energy 24/7. We don't do boring 💅", interests: ["Fashion", "Fitness", "Nightlife"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },
  { id: 59, names: "Jake & Tanner", school: "University of Southern California", age: "21 & 20", prompt: "Our thing", answer: "Row parties → beach day → rooftop sunset in DTLA 🌅", interests: ["Greek Life", "Nightlife", "Outdoors"], img1: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1534030347209-467a5b0ad3e6?w=400&h=600&fit=crop", gender: "men" },

  // MIT
  { id: 17, names: "Elena & Suki", school: "Massachusetts Institute of Technology", age: "20 & 21", prompt: "Don't let the school fool you", answer: "We code by day and dance by night 💻🕺", interests: ["Music", "Fitness", "Travel"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },
  { id: 60, names: "Rohan & Daniel", school: "Massachusetts Institute of Technology", age: "21 & 22", prompt: "Off campus", answer: "Escape rooms → ramen crawl → stargazing 🌟", interests: ["Food", "Outdoors", "Film"], img1: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=600&fit=crop", gender: "men" },

  // Yale
  { id: 18, names: "Olivia & Harper", school: "Yale University", age: "20 & 20", prompt: "Our weekend", answer: "Book shopping → coffee at Blue State → secret society vibes 📖", interests: ["Art", "Food", "Film"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },
  { id: 61, names: "Sam & Ben", school: "Yale University", age: "21 & 21", prompt: "Our style", answer: "Preppy with an edge. Boat shoes and tattoos ⛵", interests: ["Fashion", "Music", "Outdoors"], img1: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=600&fit=crop", gender: "men" },

  // Princeton
  { id: 19, names: "Claire & Audrey", school: "Princeton University", age: "19 & 20", prompt: "What we bring", answer: "We'll out-debate you and out-dance you 😏", interests: ["Greek Life", "Music", "Art"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // UPenn
  { id: 20, names: "Vivian & Serena", school: "University of Pennsylvania", age: "20 & 21", prompt: "Our ideal night", answer: "Rittenhouse dinner → speakeasy → dancing on South Street 💃", interests: ["Nightlife", "Food", "Fashion"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Georgetown
  { id: 21, names: "Alessia & Dani", school: "Georgetown University", age: "20 & 20", prompt: "DC date night", answer: "Monument walk at sunset → waterfront dinner → jazz bar 🎷", interests: ["Art", "Food", "Travel"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Northwestern
  { id: 22, names: "Piper & Quinn", school: "Northwestern University", age: "21 & 21", prompt: "Chicago weekend", answer: "Art Institute → deep dish → rooftop in Lincoln Park 🏙️", interests: ["Art", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // Vanderbilt
  { id: 23, names: "Savannah & Blair", school: "Vanderbilt University", age: "20 & 20", prompt: "Nashville nights", answer: "Broadway honky tonks → hot chicken → karaoke 🤠", interests: ["Music", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // UT Austin
  { id: 24, names: "Mariana & Jess", school: "University of Texas at Austin", age: "21 & 20", prompt: "Hook 'em", answer: "6th Street → Barton Springs → breakfast tacos at 2 AM 🌮", interests: ["Nightlife", "Outdoors", "Food"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },
  { id: 62, names: "Austin & Blake", school: "University of Texas at Austin", age: "21 & 22", prompt: "Longhorn life", answer: "Tailgate → float the river → live music on Red River 🎸", interests: ["Sports", "Music", "Outdoors"], img1: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=400&h=600&fit=crop", gender: "men" },

  // UF
  { id: 25, names: "Gabi & Tori", school: "University of Florida", age: "19 & 20", prompt: "Gator vibes", answer: "Game day → Midtown → late night Pubsubs 🐊", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // UNC
  { id: 26, names: "Brooke & Peyton", school: "University of North Carolina at Chapel Hill", age: "20 & 21", prompt: "Carolina girls", answer: "Franklin Street → sunset at the Old Well → good music 🎵", interests: ["Music", "Outdoors", "Greek Life"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },

  // UC Berkeley
  { id: 27, names: "Freya & Sage", school: "University of California, Berkeley", age: "21 & 20", prompt: "Bay Area duo", answer: "Telegraph thrifting → dim sum in SF → hike Tilden 🌿", interests: ["Outdoors", "Food", "Fashion"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // Cornell
  { id: 28, names: "Elise & Wren", school: "Cornell University", age: "20 & 20", prompt: "Ithaca is gorgeous", answer: "Gorge hikes → wine tasting → Collegetown brunch 🍷", interests: ["Outdoors", "Food", "Travel"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Notre Dame
  { id: 29, names: "Kate & Maeve", school: "University of Notre Dame", age: "20 & 21", prompt: "Under the Dome", answer: "Football Saturdays → Grotto walks → South Bend adventures 🏈", interests: ["Sports", "Food", "Outdoors"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Emory
  { id: 30, names: "Nia & Kira", school: "Emory University", age: "21 & 21", prompt: "ATL vibes", answer: "Ponce City Market → BeltLine → live music in East Atlanta 🎤", interests: ["Music", "Food", "Art"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // Rice
  { id: 31, names: "Jade & Amira", school: "Rice University", age: "20 & 20", prompt: "Houston duo", answer: "Museum district → pho in Midtown → rooftop stargazing 🌌", interests: ["Art", "Food", "Outdoors"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // WashU
  { id: 32, names: "Lena & Cora", school: "Washington University in St. Louis", age: "20 & 21", prompt: "STL hidden gems", answer: "Forest Park → The Hill for Italian → City Museum 🎨", interests: ["Art", "Food", "Outdoors"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },

  // Dartmouth
  { id: 33, names: "Tessa & Margot", school: "Dartmouth College", age: "20 & 20", prompt: "Hanover life", answer: "Skiing → bonfire → cozy cabin nights with hot cocoa ❄️", interests: ["Outdoors", "Greek Life", "Music"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // UVA
  { id: 34, names: "Caroline & Blair", school: "University of Virginia", age: "21 & 21", prompt: "On the Lawn", answer: "Foxfield → the Corner → downtown mall brunch ☀️", interests: ["Greek Life", "Food", "Outdoors"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },

  // Miami
  { id: 35, names: "Luna & Sol", school: "University of Miami", age: "20 & 20", prompt: "305 energy", answer: "South Beach → Wynwood walls → croquetas at 3 AM 🌴", interests: ["Nightlife", "Art", "Food"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // Johns Hopkins
  { id: 36, names: "Aditi & Mina", school: "Johns Hopkins University", age: "21 & 20", prompt: "Baltimore surprise", answer: "Inner Harbor → Fells Point bars → Federal Hill sunrise 🌅", interests: ["Food", "Nightlife", "Travel"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Tulane
  { id: 37, names: "Mardi & Bree", school: "Tulane University", age: "20 & 21", prompt: "NOLA nights", answer: "Magazine Street → beignets → dancing on Frenchmen 🎺", interests: ["Music", "Nightlife", "Food"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Ohio State
  { id: 63, names: "Carter & Drew", school: "Ohio State University", age: "20 & 21", prompt: "O-H!", answer: "I-O! Tailgate at the Shoe → High Street → Insomnia Cookies 🏈", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1534030347209-467a5b0ad3e6?w=400&h=600&fit=crop", gender: "men" },

  // Georgia Tech
  { id: 38, names: "Ananya & Zara", school: "Georgia Institute of Technology", age: "20 & 20", prompt: "Atlanta duo", answer: "Midtown brunch → Piedmont Park → live show at Tabernacle 🎶", interests: ["Music", "Outdoors", "Food"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // BU
  { id: 39, names: "Fiona & Willa", school: "Boston University", age: "19 & 20", prompt: "Bean Town besties", answer: "Newbury Street → North End cannoli → harbor walk 🦞", interests: ["Food", "Fashion", "Travel"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // UW
  { id: 40, names: "Rain & Autumn", school: "University of Washington", age: "21 & 21", prompt: "PNW duo", answer: "Pike Place → Capitol Hill nightlife → ferry to Bainbridge 🌲", interests: ["Outdoors", "Music", "Food"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },

  // NEW SCHOOLS
  // Florida State
  { id: 70, names: "Kylie & Megan", school: "Florida State University", age: "20 & 20", prompt: "Nole nation", answer: "Game day at Doak → College Town → waterfront sunset 🍢", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // Arizona State
  { id: 71, names: "Destiny & Raven", school: "Arizona State University", age: "21 & 21", prompt: "Desert duo", answer: "Mill Ave → Tempe Town Lake → Scottsdale brunch 🌵", interests: ["Nightlife", "Fitness", "Food"], img1: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=400&h=600&fit=crop", gender: "women" },
  { id: 72, names: "Bryce & Colton", school: "Arizona State University", age: "20 & 21", prompt: "Sun Devils", answer: "Pool party → hiking Camelback → late night tacos 🏜️", interests: ["Outdoors", "Fitness", "Nightlife"], img1: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?w=400&h=600&fit=crop", gender: "men" },

  // Penn State
  { id: 73, names: "Lexi & Paige", school: "Pennsylvania State University", age: "19 & 20", prompt: "Happy Valley", answer: "White out game → Canyon Pizza → Beaver Ave adventures 🦁", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // Purdue
  { id: 74, names: "Anika & River", school: "Purdue University", age: "20 & 20", prompt: "Boilermakers", answer: "Breakfast Club → engineering builds → Chauncey Hill 🚂", interests: ["Sports", "Food", "Music"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Indiana
  { id: 75, names: "Sadie & June", school: "Indiana University Bloomington", age: "20 & 21", prompt: "Hoosier duo", answer: "Little 500 → Kirkwood → lake days at Monroe 🚲", interests: ["Sports", "Music", "Outdoors"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Wisconsin
  { id: 76, names: "Britt & Hailey", school: "University of Wisconsin-Madison", age: "21 & 20", prompt: "On Wisconsin", answer: "State Street → Terrace at sunset → jump around at Camp Randall 🏟️", interests: ["Sports", "Nightlife", "Food"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },
  { id: 77, names: "Nate & Cooper", school: "University of Wisconsin-Madison", age: "21 & 21", prompt: "Badger boys", answer: "Tailgate → State Street bars → cheese curds at midnight 🧀", interests: ["Sports", "Greek Life", "Food"], img1: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=600&fit=crop", gender: "men" },

  // Northeastern
  { id: 78, names: "Priya & Zoe", school: "Northeastern University", age: "20 & 20", prompt: "Boston co-op queens", answer: "Fenway → Back Bay shopping → late night in Allston 🏙️", interests: ["Food", "Fashion", "Travel"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // GW
  { id: 79, names: "Morgan & Sloan", school: "George Washington University", age: "21 & 21", prompt: "DC power duo", answer: "Georgetown brunch → National Mall → Adams Morgan nightlife 🏛️", interests: ["Food", "Art", "Nightlife"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },

  // Tufts
  { id: 80, names: "Wren & Olive", school: "Tufts University", age: "19 & 20", prompt: "Jumbo duo", answer: "Davis Square → Somerville eats → Boston day trips 🐘", interests: ["Food", "Art", "Outdoors"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // Colorado
  { id: 81, names: "Aspen & Sierra", school: "University of Colorado Boulder", age: "20 & 20", prompt: "CU Boulder", answer: "Hiking the Flatirons → Pearl Street → live music on the Hill 🏔️", interests: ["Outdoors", "Music", "Fitness"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },
  { id: 82, names: "Cody & Finn", school: "University of Colorado Boulder", age: "21 & 22", prompt: "Mountain boys", answer: "Skiing → craft beer → sunset at Chautauqua 🎿", interests: ["Outdoors", "Sports", "Music"], img1: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1534030347209-467a5b0ad3e6?w=400&h=600&fit=crop", gender: "men" },

  // Oregon
  { id: 83, names: "Hazel & Fern", school: "University of Oregon", age: "20 & 21", prompt: "Duck duo", answer: "Autzen tailgate → hiking Spencer Butte → Eugene food scene 🦆", interests: ["Outdoors", "Sports", "Food"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Villanova
  { id: 84, names: "Sienna & Gianna", school: "Villanova University", age: "20 & 20", prompt: "Main Line duo", answer: "Bryn Mawr brunch → Philly day trip → Nova Nation game nights 🏀", interests: ["Food", "Sports", "Fashion"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Wake Forest
  { id: 85, names: "Hadley & Blair", school: "Wake Forest University", age: "21 & 21", prompt: "Winston duo", answer: "Reynolda Gardens → downtown arts district → Deacon games 🎭", interests: ["Art", "Sports", "Outdoors"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // Virginia Tech
  { id: 86, names: "Madison & Taylor", school: "Virginia Tech", age: "20 & 20", prompt: "Hokie duo", answer: "Lane Stadium → downtown Blacksburg → McBryde Hall study dates 🦃", interests: ["Sports", "Outdoors", "Food"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // Syracuse
  { id: 87, names: "Harper & Dylan", school: "Syracuse University", age: "19 & 20", prompt: "Cuse duo", answer: "Marshall Street → dome games → Armory Square weekend 🍊", interests: ["Sports", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // Texas A&M
  { id: 88, names: "Logan & Hunter", school: "Texas A&M University", age: "21 & 21", prompt: "Aggies", answer: "Midnight Yell → Northgate → fish camp traditions 👍", interests: ["Sports", "Greek Life", "Outdoors"], img1: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=400&h=600&fit=crop", gender: "men" },

  // UConn
  { id: 89, names: "Kayla & Nina", school: "University of Connecticut", age: "20 & 20", prompt: "Husky duo", answer: "Storrs vibes → Ted's at midnight → UConn basketball 🏀", interests: ["Sports", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },

  // UCSD
  { id: 90, names: "Mei & Yuki", school: "University of California, San Diego", age: "20 & 21", prompt: "La Jolla duo", answer: "Gliderport → ramen in Convoy → sunset at Scripps Pier 🌊", interests: ["Food", "Outdoors", "Art"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // UCSB
  { id: 91, names: "Isla & Coral", school: "University of California, Santa Barbara", age: "19 & 20", prompt: "Isla Vista", answer: "Beach day → DP → Freebirds at 2 AM 🏖️", interests: ["Outdoors", "Nightlife", "Music"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // South Carolina
  { id: 92, names: "Kennedy & Ainsley", school: "University of South Carolina", age: "20 & 20", prompt: "Gamecock duo", answer: "Five Points → Williams-Brice → Vista brunch 🐔", interests: ["Greek Life", "Sports", "Nightlife"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Alabama
  { id: 93, names: "Shelby & Anna", school: "University of Alabama", age: "19 & 20", prompt: "Roll Tide", answer: "Bryant-Denny → The Strip → game day traditions 🏈", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },
  { id: 94, names: "Trey & Jameson", school: "University of Alabama", age: "21 & 21", prompt: "Bama boys", answer: "Tailgate → Innisfree → late night Cookout 🍔", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?w=400&h=600&fit=crop", gender: "men" },

  // Georgia
  { id: 95, names: "Ellie & Josie", school: "University of Georgia", age: "20 & 20", prompt: "Go Dawgs", answer: "Downtown Athens → game day at Sanford → Taco Stand 🐶", interests: ["Sports", "Greek Life", "Food"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },

  // Pitt
  { id: 96, names: "Cassie & Bri", school: "University of Pittsburgh", age: "20 & 21", prompt: "Steel City duo", answer: "Oakland → Strip District → PNC Park sunset 🌉", interests: ["Food", "Sports", "Art"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // Rutgers
  { id: 97, names: "Valentina & Lucia", school: "Rutgers University", age: "20 & 20", prompt: "Scarlet Knights", answer: "College Ave → Fat Sandwiches → NYC weekend trips 🏙️", interests: ["Food", "Nightlife", "Travel"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // Minnesota
  { id: 98, names: "Ingrid & Solveig", school: "University of Minnesota", age: "21 & 21", prompt: "Twin Cities duo", answer: "Dinkytown → Mill City → North Loop food scene 🌟", interests: ["Food", "Art", "Outdoors"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },

  // Maryland
  { id: 99, names: "Asha & Diya", school: "University of Maryland", age: "20 & 20", prompt: "Terps duo", answer: "Route 1 → DC day trips → Stamp student union 🐢", interests: ["Food", "Travel", "Music"], img1: "https://images.unsplash.com/photo-1514315384763-ba401779410f?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=400&h=600&fit=crop", gender: "women" },

  // Iowa
  { id: 100, names: "Molly & Kelsey", school: "University of Iowa", age: "19 & 20", prompt: "Hawkeye duo", answer: "Kinnick wave → Ped Mall → Iowa City nightlife 🦅", interests: ["Sports", "Nightlife", "Music"], img1: "https://images.unsplash.com/photo-1496440737103-cd596325d314?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=400&h=600&fit=crop", gender: "women" },

  // Rochester
  { id: 101, names: "Ada & Iris", school: "University of Rochester", age: "20 & 20", prompt: "Rochester duo", answer: "Eastman concerts → Park Ave → Finger Lakes winery trips 🎻", interests: ["Music", "Food", "Travel"], img1: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop", gender: "women" },

  // Arizona
  { id: 102, names: "Sasha & Daria", school: "University of Arizona", age: "20 & 21", prompt: "Wildcats", answer: "4th Ave → hiking Sabino Canyon → Tucson sunsets 🌅", interests: ["Outdoors", "Nightlife", "Food"], img1: "https://images.unsplash.com/photo-1485875437071-bb71a38b1e2c?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1523264653568-d3d4a18e3675?w=400&h=600&fit=crop", gender: "women" },

  // MSU
  { id: 103, names: "Sparty & Co", school: "Michigan State University", age: "20 & 20", prompt: "Spartans", answer: "Grand River → Spartan Stadium → East Lansing vibes 💚", interests: ["Sports", "Greek Life", "Nightlife"], img1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600&fit=crop", gender: "women" },
  { id: 104, names: "Zach & Grant", school: "Michigan State University", age: "21 & 21", prompt: "Sparty boys", answer: "Crunchy's → tailgate → late night Conrad's 🌮", interests: ["Sports", "Food", "Nightlife"], img1: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=600&fit=crop", gender: "men" },

  // Caltech
  { id: 105, names: "Vera & Nadia", school: "California Institute of Technology", age: "21 & 22", prompt: "Caltech duo", answer: "Pasadena vibes → JPL tours → late night problem sets 🔬", interests: ["Food", "Outdoors", "Film"], img1: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1464863979621-258859e62245?w=400&h=600&fit=crop", gender: "women" },

  // CMU
  { id: 106, names: "Mei-Lin & Preet", school: "Carnegie Mellon University", age: "20 & 20", prompt: "CMU duo", answer: "Pittsburgh tech scene → Squirrel Hill eats → Frick Park hikes 🐿️", interests: ["Food", "Art", "Outdoors"], img1: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop", gender: "women" },

  // Boston College
  { id: 107, names: "Bridget & Colleen", school: "Boston College", age: "20 & 21", prompt: "Eagles", answer: "Mod Night → Chestnut Hill → marathon Monday vibes 🦅", interests: ["Sports", "Greek Life", "Food"], img1: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=600&fit=crop", img2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=600&fit=crop", gender: "women" },
];

export const getSchoolsFromDuos = () => {
  const schools = new Set(allDuos.map((d) => d.school));
  return ["My School", "All Universities", ...Array.from(schools).sort()];
};
