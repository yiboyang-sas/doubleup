/**
 * Advanced state management utilities
 */

import { useState, useCallback, useRef as useReactRef, useEffect } from 'react';

/**
 * Persistent state (localStorage)
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      try {
        const valueToStore = value instanceof Function ? (value as any)(storedValue) : value;
        setStoredValue(valueToStore);
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.error(`Error setting localStorage key "${key}":`, error);
      }
    },
    [key, storedValue],
  );

  const removeValue = useCallback(() => {
    try {
      window.localStorage.removeItem(key);
      setStoredValue(initialValue);
    } catch (error) {
      console.error(`Error removing localStorage key "${key}":`, error);
    }
  }, [key, initialValue]);

  return [storedValue, setValue, removeValue] as const;
}

/**
 * Session storage
 */
export function useSessionStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.sessionStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      try {
        const valueToStore = value instanceof Function ? (value as any)(storedValue) : value;
        setStoredValue(valueToStore);
        window.sessionStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.error(`Error setting sessionStorage key "${key}":`, error);
      }
    },
    [key, storedValue],
  );

  return [storedValue, setValue] as const;
}

/**
 * Create a simple state store with selectors
 */
export function createStore<T extends Record<string, any>>(initialState: T) {
  let state = initialState;
  const listeners = new Set<(state: T) => void>();

  return {
    getState: () => state,

    setState: (newState: Partial<T> | ((prev: T) => Partial<T>)) => {
      const updates = typeof newState === 'function' ? newState(state) : newState;
      state = { ...state, ...updates };
      listeners.forEach((listener) => listener(state));
    },

    subscribe: (listener: (state: T) => void) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },

    useStore: () => {
      const [currentState, setCurrentState] = useState(state);

      useEffect(() => {
        setCurrentState(state);
        const unsubscribe = (() => {
          const listener = (newState: T) => setCurrentState(newState);
          listeners.add(listener);
          return () => listeners.delete(listener);
        })();
        return unsubscribe;
      }, []);

      return currentState;
    },
  };
}

/**
 * Undo/Redo state management
 */
export function useUndoRedo<T>(initialValue: T) {
  const [past, setPast] = useState<T[]>([]);
  const [present, setPresent] = useState(initialValue);
  const [future, setFuture] = useState<T[]>([]);

  const set = useCallback((newValue: T | ((prev: T) => T)) => {
    const next = typeof newValue === 'function'
      ? (newValue as (prev: T) => T)(present)
      : newValue;
    setPast([...past, present]);
    setPresent(next);
    setFuture([]);
  }, [present, past]);

  const undo = useCallback(() => {
    if (past.length > 0) {
      const newPresent = past[past.length - 1];
      const newPast = past.slice(0, past.length - 1);
      setPast(newPast);
      setPresent(newPresent);
      setFuture([present, ...future]);
    }
  }, [past, present, future]);

  const redo = useCallback(() => {
    if (future.length > 0) {
      const newPresent = future[0];
      const newFuture = future.slice(1);
      setPast([...past, present]);
      setPresent(newPresent);
      setFuture(newFuture);
    }
  }, [past, present, future]);

  const reset = useCallback((value: T) => {
    setPast([]);
    setPresent(value);
    setFuture([]);
  }, []);

  return {
    value: present,
    set,
    undo,
    redo,
    reset,
    canUndo: past.length > 0,
    canRedo: future.length > 0,
  };
}

/**
 * Reference-based state (doesn't trigger re-renders)
 */
export function useRefValue<T>(initialValue: T) {
  const ref = useReactRef<T>(initialValue);

  return {
    get current(): T {
      return ref.current;
    },
    set current(value: T) {
      ref.current = value;
    },
  };
}

/**
 * Reducer hook with devtools support
 */
export function useReducerWithMiddleware<S, A>(
  reducer: (state: S, action: A) => S,
  initialState: S,
  middleware?: (action: A, state: S) => void,
) {
  const [state, dispatch] = useState(initialState);

  const enhancedDispatch = useCallback(
    (action: A) => {
      if (middleware) {
        middleware(action, state);
      }
      dispatch((prevState) => reducer(prevState, action));
    },
    [reducer, middleware, state],
  );

  return [state, enhancedDispatch] as const;
}
