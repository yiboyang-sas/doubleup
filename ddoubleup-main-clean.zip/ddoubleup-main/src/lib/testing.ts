/**
 * Testing utilities and helpers for DoubleUp
 */

/**
 * Mock data generators
 */
export const mockGenerators = {
  user: (overrides = {}) => ({
    id: 'user-' + Math.random(),
    email: `test-${Math.random()}@example.com`,
    display_name: 'Test User',
    avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg',
    university: 'Test University',
    created_at: new Date().toISOString(),
    ...overrides,
  }),

  duo: (overrides = {}) => ({
    id: 'duo-' + Math.random(),
    user1_id: 'user-' + Math.random(),
    user2_id: 'user-' + Math.random(),
    prompt1: 'What is your ideal date?',
    answer1: 'Going to dinner',
    prompt2: 'Favorite thing to do on weekends?',
    answer2: 'Hang out with friends',
    interests: ['Sports', 'Music', 'Travel'],
    photo1_url: 'https://via.placeholder.com/300',
    photo2_url: 'https://via.placeholder.com/300',
    school: 'Test University',
    created_at: new Date().toISOString(),
    ...overrides,
  }),

  message: (overrides = {}) => ({
    id: 'msg-' + Math.random(),
    room_id: 'room-' + Math.random(),
    sender_id: 'user-' + Math.random(),
    content: 'Test message',
    created_at: new Date().toISOString(),
    ...overrides,
  }),

  match: (overrides = {}) => ({
    id: 'match-' + Math.random(),
    user_id: 'user-' + Math.random(),
    liked_duo_id: 'duo-' + Math.random(),
    status: 'pending' as const,
    created_at: new Date().toISOString(),
    ...overrides,
  }),
};

/**
 * Assertion helpers
 */
export const assertions = {
  isValidEmail: (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  isValidUUID: (uuid: string) => {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid);
  },

  isValidURL: (url: string) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  isRecentDate: (date: string | Date, withinMs = 60000) => {
    const dateMs = new Date(date).getTime();
    const now = new Date().getTime();
    return Math.abs(now - dateMs) <= withinMs;
  },

  isEmpty: (value: any) => {
    return value === null || value === undefined || value === '' || (Array.isArray(value) && value.length === 0);
  },

  hasAllProperties: (obj: any, properties: string[]) => {
    return properties.every((prop) => prop in obj);
  },
};

/**
 * Performance testing utilities
 */
export const performanceTest = {
  measureRender: async (component: () => void) => {
    const start = performance.now();
    component();
    const end = performance.now();
    return end - start;
  },

  measureMultiple: async (component: () => void, iterations = 100) => {
    const times: number[] = [];
    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      component();
      const end = performance.now();
      times.push(end - start);
    }
    return {
      min: Math.min(...times),
      max: Math.max(...times),
      avg: times.reduce((a, b) => a + b, 0) / times.length,
      times,
    };
  },

  memoryUsage: () => {
    if ('memory' in performance) {
      return {
        used: (performance.memory as any).usedJSHeapSize,
        total: (performance.memory as any).totalJSHeapSize,
        limit: (performance.memory as any).jsHeapSizeLimit,
      };
    }
    return null;
  },
};

/**
 * Snapshot testing utilities
 */
export const snapshot = {
  create: (data: any) => JSON.stringify(data, null, 2),

  compare: (current: any, previous: any) => {
    return JSON.stringify(current) === JSON.stringify(previous);
  },

  diff: (current: any, previous: any) => {
    const currentStr = JSON.stringify(current, null, 2);
    const previousStr = JSON.stringify(previous, null, 2);
    // Simple diff - in real scenarios, use a library like 'diff'
    return currentStr === previousStr ? null : { current: currentStr, previous: previousStr };
  },
};

/**
 * API mocking utilities
 */
export const mockAPI = {
  delay: (ms: number) => new Promise((resolve) => setTimeout(resolve, ms)),

  success: <T,>(data: T, delayMs = 100) => {
    return new Promise<T>((resolve) => {
      setTimeout(() => resolve(data), delayMs);
    });
  },

  error: (message: string, delayMs = 100) => {
    return new Promise((_, reject) => {
      setTimeout(() => reject(new Error(message)), delayMs);
    });
  },

  sequence: <T,>(results: T[], delayMs = 100) => {
    let index = 0;
    return () => {
      return new Promise<T>((resolve) => {
        setTimeout(() => resolve(results[index++ % results.length]), delayMs);
      });
    };
  },
};

/**
 * User interaction simulators
 */
export const simulateUserInteraction = {
  click: (element: HTMLElement) => {
    element.click();
  },

  type: (element: HTMLInputElement, text: string) => {
    element.value = text;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  },

  submit: (form: HTMLFormElement) => {
    form.dispatchEvent(new Event('submit', { bubbles: true }));
  },

  focus: (element: HTMLElement) => {
    element.focus();
    element.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
  },

  blur: (element: HTMLElement) => {
    element.blur();
    element.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
  },

  hover: (element: HTMLElement) => {
    element.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
    element.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
  },

  unhover: (element: HTMLElement) => {
    element.dispatchEvent(new MouseEvent('mouseleave', { bubbles: true }));
    element.dispatchEvent(new MouseEvent('mouseout', { bubbles: true }));
  },

  scroll: (element: Element, top: number) => {
    element.scrollTop = top;
    element.dispatchEvent(new Event('scroll', { bubbles: true }));
  },
};

/**
 * Data validation testing
 */
export const validateData = {
  notNull: (value: any) => value !== null && value !== undefined,
  notEmpty: (value: string) => value.trim().length > 0,
  isArray: (value: any) => Array.isArray(value),
  isObject: (value: any) => value !== null && typeof value === 'object',
  hasLength: (value: any, length: number) => value?.length === length,
  inRange: (value: number, min: number, max: number) => value >= min && value <= max,
};

/**
 * Batch testing helper
 */
export class TestBatch {
  private tests: Array<{ name: string; fn: () => void | Promise<void> }> = [];
  private results: Array<{ name: string; passed: boolean; error?: Error }> = [];

  add(name: string, fn: () => void | Promise<void>) {
    this.tests.push({ name, fn });
    return this;
  }

  async run() {
    for (const test of this.tests) {
      try {
        await test.fn();
        this.results.push({ name: test.name, passed: true });
      } catch (error) {
        this.results.push({
          name: test.name,
          passed: false,
          error: error instanceof Error ? error : new Error(String(error)),
        });
      }
    }
    return this.results;
  }

  getResults() {
    return this.results;
  }

  getSummary() {
    const total = this.results.length;
    const passed = this.results.filter((r) => r.passed).length;
    const failed = total - passed;
    return {
      total,
      passed,
      failed,
      successRate: ((passed / total) * 100).toFixed(2) + '%',
    };
  }
}
