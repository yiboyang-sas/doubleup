import { ERROR_MESSAGES } from "@/constants/app";
import { toast } from "@/hooks/use-toast";

// Custom error class
export class AppError extends Error {
  constructor(
    public code: string,
    message: string,
    public details?: Record<string, any>,
  ) {
    super(message);
    this.name = "AppError";
  }
}

// Error codes
export const ERROR_CODES = {
  AUTH_INVALID_EMAIL: "AUTH_INVALID_EMAIL",
  AUTH_WEAK_PASSWORD: "AUTH_WEAK_PASSWORD",
  AUTH_USER_NOT_FOUND: "AUTH_USER_NOT_FOUND",
  AUTH_INVALID_CREDENTIALS: "AUTH_INVALID_CREDENTIALS",
  AUTH_TOKEN_EXPIRED: "AUTH_TOKEN_EXPIRED",

  VALIDATION_REQUIRED: "VALIDATION_REQUIRED",
  VALIDATION_INVALID_FORMAT: "VALIDATION_INVALID_FORMAT",
  VALIDATION_TOO_SHORT: "VALIDATION_TOO_SHORT",
  VALIDATION_TOO_LONG: "VALIDATION_TOO_LONG",

  FILE_UNSUPPORTED_TYPE: "FILE_UNSUPPORTED_TYPE",
  FILE_TOO_LARGE: "FILE_TOO_LARGE",
  FILE_UPLOAD_FAILED: "FILE_UPLOAD_FAILED",

  NETWORK_ERROR: "NETWORK_ERROR",
  NETWORK_TIMEOUT: "NETWORK_TIMEOUT",

  DATABASE_ERROR: "DATABASE_ERROR",
  DATABASE_CONFLICT: "DATABASE_CONFLICT",

  NOT_FOUND: "NOT_FOUND",
  PERMISSION_DENIED: "PERMISSION_DENIED",
  RATE_LIMITED: "RATE_LIMITED",

  UNKNOWN: "UNKNOWN",
} as const;

// Error handler
export function handleError(error: unknown): AppError {
  if (error instanceof AppError) {
    return error;
  }

  if (error instanceof Error) {
    console.error("Error:", error.message);
    return new AppError(ERROR_CODES.UNKNOWN, error.message);
  }

  console.error("Unknown error:", error);
  return new AppError(ERROR_CODES.UNKNOWN, "An unexpected error occurred");
}

// Toast error
export function showErrorToast(error: AppError | Error | string, title = "Error") {
  const message = typeof error === "string" ? error : error.message;
  toast({
    title,
    description: message,
    variant: "destructive",
  });
}

// Validation error handler
export function validateRequired(value: string | undefined, fieldName: string): string | null {
  if (!value || !value.trim()) {
    return `${fieldName} is required`;
  }
  return null;
}

export function validateEmail(email: string): string | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.trim()) {
    return "Email is required";
  }
  if (!emailRegex.test(email)) {
    return "Please enter a valid email address";
  }
  return null;
}

export function validatePassword(password: string, minLength = 8): string | null {
  if (!password) {
    return "Password is required";
  }
  if (password.length < minLength) {
    return `Password must be at least ${minLength} characters`;
  }
  return null;
}

export function validateMinLength(value: string, minLength: number, fieldName: string): string | null {
  if (!value || value.length < minLength) {
    return `${fieldName} must be at least ${minLength} characters`;
  }
  return null;
}

export function validateMaxLength(value: string, maxLength: number, fieldName: string): string | null {
  if (value && value.length > maxLength) {
    return `${fieldName} cannot exceed ${maxLength} characters`;
  }
  return null;
}

// Async error handler with retry
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  delay = 1000,
): Promise<T> {
  let lastError: Error | null = null;

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (i < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delay * Math.pow(2, i)));
      }
    }
  }

  throw lastError || new Error("Max retries exceeded");
}

// Safe async executor
export async function safeAsync<T>(
  fn: () => Promise<T>,
  errorHandler?: (error: Error) => void,
): Promise<[T | null, Error | null]> {
  try {
    const result = await fn();
    return [result, null];
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    if (errorHandler) {
      errorHandler(err);
    }
    return [null, err];
  }
}
