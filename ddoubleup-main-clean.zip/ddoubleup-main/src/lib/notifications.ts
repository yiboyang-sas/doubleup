/**
 * Advanced notifications and messaging utilities
 */

import { toast } from '@/hooks/use-toast';

export type NotificationType = 'success' | 'error' | 'warning' | 'info';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

class NotificationManager {
  private notifications: Map<string, Notification> = new Map();
  private listeners: Array<(notifications: Notification[]) => void> = [];

  private generateId(): string {
    return `notif-${Date.now()}-${Math.random()}`;
  }

  show(
    type: NotificationType,
    title: string,
    message: string,
    options?: {
      duration?: number;
      action?: { label: string; onClick: () => void };
    },
  ): string {
    const id = this.generateId();
    const notification: Notification = {
      id,
      type,
      title,
      message,
      duration: options?.duration,
      action: options?.action,
    };

    this.notifications.set(id, notification);
    this.notifyListeners();

    // Auto-dismiss
    if (options?.duration !== 0) {
      setTimeout(() => this.dismiss(id), options?.duration ?? 4000);
    }

    // Also use toast for system-level notification
    toast({
      title,
      description: message,
      variant: type === 'error' ? 'destructive' : 'default',
    });

    return id;
  }

  success(title: string, message: string, options?: Parameters<typeof this.show>[3]) {
    return this.show('success', title, message, options);
  }

  error(title: string, message: string, options?: Parameters<typeof this.show>[3]) {
    return this.show('error', title, message, options);
  }

  warning(title: string, message: string, options?: Parameters<typeof this.show>[3]) {
    return this.show('warning', title, message, options);
  }

  info(title: string, message: string, options?: Parameters<typeof this.show>[3]) {
    return this.show('info', title, message, options);
  }

  dismiss(id: string) {
    this.notifications.delete(id);
    this.notifyListeners();
  }

  dismissAll() {
    this.notifications.clear();
    this.notifyListeners();
  }

  getAll(): Notification[] {
    return Array.from(this.notifications.values());
  }

  onChange(callback: (notifications: Notification[]) => void) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.getAll()));
  }
}

export const notificationManager = new NotificationManager();

/**
 * Hook for using notifications
 */
import { useState, useEffect } from 'react';

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    return notificationManager.onChange(setNotifications);
  }, []);

  return {
    notifications,
    show: notificationManager.show.bind(notificationManager),
    success: notificationManager.success.bind(notificationManager),
    error: notificationManager.error.bind(notificationManager),
    warning: notificationManager.warning.bind(notificationManager),
    info: notificationManager.info.bind(notificationManager),
    dismiss: notificationManager.dismiss.bind(notificationManager),
    dismissAll: notificationManager.dismissAll.bind(notificationManager),
  };
}

/**
 * Toast notification with promise handling
 */
export async function toastPromise<T>(
  promise: Promise<T>,
  {
    loading,
    success,
    error: errorMsg,
  }: {
    loading: string;
    success: (data: T) => string;
    error: (err: Error) => string;
  },
): Promise<T> {
  const loadingId = notificationManager.info('Loading', loading, { duration: 0 });

  try {
    const result = await promise;
    notificationManager.dismiss(loadingId);
    notificationManager.success('Success', success(result));
    return result;
  } catch (err) {
    notificationManager.dismiss(loadingId);
    const errorText = err instanceof Error ? err.message : 'Unknown error';
    notificationManager.error('Error', errorMsg(new Error(errorText)));
    throw err;
  }
}
