/**
 * Advanced performance utilities for optimization
 */

/**
 * Memoize function results
 */
export function memoize<T extends (...args: any[]) => any>(fn: T): T {
  const cache = new Map();

  return ((...args: any[]) => {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      return cache.get(key);
    }
    const result = fn(...args);
    cache.set(key, result);
    return result;
  }) as T;
}

/**
 * Create a computed value with caching
 */
export function createComputed<T>(
  dependencies: any[],
  compute: () => T,
  lastValue?: T,
): T {
  const depsChanged = !lastValue || JSON.stringify(dependencies) !== JSON.stringify(lastValue);
  return depsChanged ? compute() : lastValue;
}

/**
 * Batch multiple state updates
 */
export function batch(fn: () => void) {
  // React 18+ handles batching automatically
  fn();
}

/**
 * Request idle callback with fallback
 */
export function scheduleIdleTask(callback: () => void) {
  if (typeof requestIdleCallback !== 'undefined') {
    requestIdleCallback(callback);
  } else {
    setTimeout(callback, 0);
  }
}

/**
 * Intersection Observer for lazy loading
 */
export function observeIntersection(
  element: Element,
  callback: (isVisible: boolean) => void,
  options?: IntersectionObserverInit,
) {
  const observer = new IntersectionObserver(([entry]) => {
    callback(entry.isIntersecting);
  }, options);

  observer.observe(element);
  return () => observer.disconnect();
}

/**
 * Preload image for better performance
 */
export function preloadImage(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = () => reject(new Error(`Failed to preload image: ${src}`));
    img.src = src;
  });
}

/**
 * Debounced function with immediate option
 */
export function debounceWithImmediate<T extends (...args: any[]) => any>(
  fn: T,
  delayMs: number,
  immediate = false,
): T {
  let timeoutId: NodeJS.Timeout | null = null;

  return ((...args: any[]) => {
    const later = () => {
      timeoutId = null;
      if (!immediate) fn(...args);
    };

    const callNow = immediate && !timeoutId;
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(later, delayMs);
    if (callNow) fn(...args);
  }) as T;
}

/**
 * Throttle function for rate limiting
 */
export function throttle<T extends (...args: any[]) => any>(
  fn: T,
  limitMs: number,
): T {
  let inThrottle = false;

  return ((...args: any[]) => {
    if (!inThrottle) {
      fn(...args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limitMs);
    }
  }) as T;
}

/**
 * Compose functions together
 */
export function compose<T>(...fns: Array<(arg: T) => T>): (arg: T) => T {
  return (arg: T) => fns.reduceRight((acc, fn) => fn(acc), arg);
}

/**
 * Pipe functions together
 */
export function pipe<T>(...fns: Array<(arg: T) => T>): (arg: T) => T {
  return (arg: T) => fns.reduce((acc, fn) => fn(acc), arg);
}

/**
 * Retry a function with exponential backoff
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  baseDelayMs = 1000,
): Promise<T> {
  let lastError: Error | null = null;

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (i < maxRetries - 1) {
        const delayMs = baseDelayMs * Math.pow(2, i);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }

  throw lastError;
}

/**
 * Cancellable promise
 */
export function makeCancelable<T>(promise: Promise<T>) {
  let hasCanceled = false;

  const wrappedPromise = new Promise<T>((resolve, reject) => {
    promise
      .then((value) => {
        if (!hasCanceled) resolve(value);
      })
      .catch((error) => {
        if (!hasCanceled) reject(error);
      });
  });

  return {
    promise: wrappedPromise,
    cancel: () => {
      hasCanceled = true;
    },
  };
}

/**
 * Measure performance
 */
export function measurePerformance<T>(
  name: string,
  fn: () => T,
): { result: T; duration: number } {
  const start = performance.now();
  const result = fn();
  const duration = performance.now() - start;

  if (process.env.NODE_ENV === 'development') {
    console.debug(`[Performance] ${name}: ${duration.toFixed(2)}ms`);
  }

  return { result, duration };
}
