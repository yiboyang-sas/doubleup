/**
 * Advanced networking and API utilities
 */

export interface ApiClientConfig {
  baseURL: string;
  timeout: number;
  retries: number;
  headers?: Record<string, string>;
}

export interface RequestInterceptor {
  (config: RequestInit): RequestInit;
}

export interface ResponseInterceptor<T> {
  (response: Response, data: T): T;
}

class ApiClient {
  private config: ApiClientConfig;
  private requestInterceptors: RequestInterceptor[] = [];
  private responseInterceptors: ResponseInterceptor<any>[] = [];

  constructor(config: Partial<ApiClientConfig> = {}) {
    this.config = {
      baseURL: '',
      timeout: 30000,
      retries: 3,
      ...config,
    };
  }

  use(interceptor: 'request' | 'response', fn: any) {
    if (interceptor === 'request') {
      this.requestInterceptors.push(fn);
    } else {
      this.responseInterceptors.push(fn);
    }
  }

  private applyRequestInterceptors(config: RequestInit): RequestInit {
    return this.requestInterceptors.reduce((acc, interceptor) => interceptor(acc), config);
  }

  private async applyResponseInterceptors<T>(response: Response, data: T): Promise<T> {
    return this.responseInterceptors.reduce(
      async (acc, interceptor) => interceptor(response, await acc),
      Promise.resolve(data),
    );
  }

  async get<T>(url: string, config?: RequestInit): Promise<T> {
    return this.request<T>(url, { ...config, method: 'GET' });
  }

  async post<T>(url: string, body?: any, config?: RequestInit): Promise<T> {
    return this.request<T>(url, {
      ...config,
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  async put<T>(url: string, body?: any, config?: RequestInit): Promise<T> {
    return this.request<T>(url, {
      ...config,
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  async patch<T>(url: string, body?: any, config?: RequestInit): Promise<T> {
    return this.request<T>(url, {
      ...config,
      method: 'PATCH',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  async delete<T>(url: string, config?: RequestInit): Promise<T> {
    return this.request<T>(url, { ...config, method: 'DELETE' });
  }

  private async request<T>(
    url: string,
    config: RequestInit = {},
    retryCount = 0,
  ): Promise<T> {
    const fullUrl = url.startsWith('http') ? url : `${this.config.baseURL}${url}`;

    let finalConfig: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...this.config.headers,
        ...config.headers,
      },
      ...config,
    };

    finalConfig = this.applyRequestInterceptors(finalConfig);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(fullUrl, {
        ...finalConfig,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }

      const data = await response.json();
      return this.applyResponseInterceptors(response, data);
    } catch (error) {
      clearTimeout(timeoutId);

      if (retryCount < this.config.retries) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * Math.pow(2, retryCount)));
        return this.request<T>(url, config, retryCount + 1);
      }

      throw error;
    }
  }
}

export const apiClient = new ApiClient({
  baseURL: process.env.REACT_APP_API_URL || '',
  timeout: 30000,
  retries: 3,
});

/**
 * Query cache for reducing network requests
 */
export class QueryCache {
  private cache = new Map<string, { data: any; timestamp: number }>();
  private defaultTTL = 5 * 60 * 1000; // 5 minutes

  set(key: string, data: any, ttl = this.defaultTTL) {
    this.cache.set(key, {
      data,
      timestamp: Date.now() + ttl,
    });
  }

  get(key: string) {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.timestamp) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  clear() {
    this.cache.clear();
  }

  has(key: string) {
    const entry = this.cache.get(key);
    if (!entry) return false;
    if (Date.now() > entry.timestamp) {
      this.cache.delete(key);
      return false;
    }
    return true;
  }
}

export const queryCache = new QueryCache();

/**
 * Network status detection
 */
export class NetworkStatus {
  private listeners: Array<(isOnline: boolean) => void> = [];

  constructor() {
    window.addEventListener('online', () => this.notifyListeners(true));
    window.addEventListener('offline', () => this.notifyListeners(false));
  }

  isOnline(): boolean {
    return navigator.onLine;
  }

  onChange(callback: (isOnline: boolean) => void) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notifyListeners(isOnline: boolean) {
    this.listeners.forEach((listener) => listener(isOnline));
  }
}

export const networkStatus = new NetworkStatus();
