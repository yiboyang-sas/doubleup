/**
 * Analytics module for tracking user events and performance
 */

import React from 'react';

export interface AnalyticsEvent {
  name: string;
  category: string;
  label?: string;
  value?: number;
  timestamp: number;
  userId?: string;
}

export interface AnalyticsConfig {
  enabled: boolean;
  trackPageViews: boolean;
  trackEvents: boolean;
  trackPerformance: boolean;
  debug: boolean;
}

class Analytics {
  private events: AnalyticsEvent[] = [];
  private config: AnalyticsConfig = {
    enabled: true,
    trackPageViews: true,
    trackEvents: true,
    trackPerformance: true,
    debug: false,
  };

  configure(config: Partial<AnalyticsConfig>) {
    this.config = { ...this.config, ...config };
  }

  track(name: string, category: string, label?: string, value?: number) {
    if (!this.config.enabled || !this.config.trackEvents) return;

    const event: AnalyticsEvent = {
      name,
      category,
      label,
      value,
      timestamp: Date.now(),
    };

    this.events.push(event);

    if (this.config.debug) {
      console.log('[Analytics]', event);
    }

    // In production, send to analytics service
    this.sendToAnalytics(event);
  }

  trackPageView(pageName: string) {
    if (!this.config.enabled || !this.config.trackPageViews) return;

    this.track('page_view', 'navigation', pageName);
  }

  trackPerformance(metricName: string, duration: number) {
    if (!this.config.enabled || !this.config.trackPerformance) return;

    this.track('performance', 'timing', metricName, duration);
  }

  trackError(error: Error, context?: Record<string, any>) {
    if (!this.config.enabled) return;

    this.track('error', 'error', error.message);

    if (this.config.debug) {
      console.error('[Analytics Error]', error, context);
    }
  }

  trackConversion(conversionName: string, value?: number) {
    this.track('conversion', 'monetization', conversionName, value);
  }

  private sendToAnalytics(event: AnalyticsEvent) {
    // Implement sending to your analytics provider
    // Examples: Google Analytics, Mixpanel, Segment, etc.
    // For now, just log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.debug('[Analytics Send]', event);
    }
  }

  getEvents() {
    return [...this.events];
  }

  clearEvents() {
    this.events = [];
  }
}

export const analytics = new Analytics();

/**
 * Hook for tracking component mount/unmount
 */
export function useAnalyticsPageView(pageName: string) {
  React.useEffect(() => {
    analytics.trackPageView(pageName);
  }, [pageName]);
}

/**
 * Hook for tracking specific events
 */
export function useAnalyticsEvent(
  eventName: string,
  category: string,
  dependencies: any[] = [],
) {
  const trackEvent = React.useCallback(
    (label?: string, value?: number) => {
      analytics.track(eventName, category, label, value);
    },
    [eventName, category],
  );

  return trackEvent;
}
