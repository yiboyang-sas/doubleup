/**
 * Advanced validation schema with better error messages
 */

export interface ValidationRule {
  validate: (value: any) => boolean;
  message: string;
}

export interface ValidationSchema {
  [field: string]: ValidationRule | ValidationRule[];
}

class Validator {
  private schemas: Map<string, ValidationSchema> = new Map();

  registerSchema(name: string, schema: ValidationSchema) {
    this.schemas.set(name, schema);
  }

  validate<T extends Record<string, any>>(data: T, schema: ValidationSchema): Record<string, string> {
    const errors: Record<string, string> = {};

    for (const [field, rules] of Object.entries(schema)) {
      const value = data[field];
      const rulesArray = Array.isArray(rules) ? rules : [rules];

      for (const rule of rulesArray) {
        if (!rule.validate(value)) {
          errors[field] = rule.message;
          break;
        }
      }
    }

    return errors;
  }

  validateField(value: any, rules: ValidationRule | ValidationRule[]): string | null {
    const rulesArray = Array.isArray(rules) ? rules : [rules];

    for (const rule of rulesArray) {
      if (!rule.validate(value)) {
        return rule.message;
      }
    }

    return null;
  }
}

export const validator = new Validator();

// Built-in validation rules
export const Rules = {
  required: (msg = 'This field is required'): ValidationRule => ({
    validate: (value: any) => value !== null && value !== undefined && value !== '',
    message: msg,
  }),

  email: (msg = 'Invalid email address'): ValidationRule => ({
    validate: (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    message: msg,
  }),

  minLength: (length: number, msg?: string): ValidationRule => ({
    validate: (value: string) => value.length >= length,
    message: msg || `Minimum length is ${length} characters`,
  }),

  maxLength: (length: number, msg?: string): ValidationRule => ({
    validate: (value: string) => value.length <= length,
    message: msg || `Maximum length is ${length} characters`,
  }),

  pattern: (regex: RegExp, msg = 'Invalid format'): ValidationRule => ({
    validate: (value: string) => regex.test(value),
    message: msg,
  }),

  match: (otherValue: any, msg = 'Values do not match'): ValidationRule => ({
    validate: (value: any) => value === otherValue,
    message: msg,
  }),

  custom: (fn: (value: any) => boolean, msg = 'Validation failed'): ValidationRule => ({
    validate: fn,
    message: msg,
  }),

  minValue: (min: number, msg?: string): ValidationRule => ({
    validate: (value: number) => value >= min,
    message: msg || `Minimum value is ${min}`,
  }),

  maxValue: (max: number, msg?: string): ValidationRule => ({
    validate: (value: number) => value <= max,
    message: msg || `Maximum value is ${max}`,
  }),

  url: (msg = 'Invalid URL'): ValidationRule => ({
    validate: (value: string) => {
      try {
        new URL(value);
        return true;
      } catch {
        return false;
      }
    },
    message: msg,
  }),

  phone: (msg = 'Invalid phone number'): ValidationRule => ({
    validate: (value: string) => /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}$/.test(value),
    message: msg,
  }),

  creditCard: (msg = 'Invalid credit card number'): ValidationRule => ({
    validate: (value: string) => {
      const sanitized = value.replace(/\s/g, '');
      return /^\d{13,19}$/.test(sanitized) && luhnCheck(sanitized);
    },
    message: msg,
  }),
};

// Luhn algorithm for credit card validation
function luhnCheck(num: string): boolean {
  let sum = 0;
  let isEven = false;

  for (let i = num.length - 1; i >= 0; i--) {
    let digit = parseInt(num.charAt(i), 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Form data sanitizer to prevent XSS
 */
export function sanitizeInput(input: string): string {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
}

/**
 * Validation result with success/error
 */
export interface ValidationResult<T> {
  success: boolean;
  data?: T;
  errors?: Record<string, string>;
}

export function validateData<T extends Record<string, any>>(
  data: T,
  schema: ValidationSchema,
): ValidationResult<T> {
  const errors = validator.validate(data, schema);

  if (Object.keys(errors).length > 0) {
    return { success: false, errors };
  }

  return { success: true, data };
}
