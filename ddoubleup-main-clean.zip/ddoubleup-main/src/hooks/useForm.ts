import { useState, useCallback } from 'react';

export interface FormField<T> {
  value: T;
  error: string | null;
  touched: boolean;
  isDirty: boolean;
}

export interface FormState<T> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  touched: Partial<Record<keyof T, boolean>>;
  dirty: Partial<Record<keyof T, boolean>>;
  isSubmitting: boolean;
  isValid: boolean;
}

/**
 * Advanced form hook with validation
 */
export function useForm<T extends Record<string, any>>(
  initialValues: T,
  onSubmit: (values: T) => Promise<void>,
  validate?: (values: T) => Partial<Record<keyof T, string>>,
) {
  const [state, setState] = useState<FormState<T>>({
    values: initialValues,
    errors: {},
    touched: {},
    dirty: {},
    isSubmitting: false,
    isValid: true,
  });

  const validateForm = useCallback(
    (values: T) => {
      if (!validate) return {};
      return validate(values);
    },
    [validate],
  );

  const setFieldValue = useCallback(
    (field: keyof T, value: any) => {
      setState((prev) => ({
        ...prev,
        values: { ...prev.values, [field]: value },
        dirty: { ...prev.dirty, [field]: true },
      }));
    },
    [],
  );

  const setFieldError = useCallback((field: keyof T, error: string | null) => {
    setState((prev) => ({
      ...prev,
      errors: error ? { ...prev.errors, [field]: error } : { ...prev.errors },
    }));
  }, []);

  const setFieldTouched = useCallback((field: keyof T, touched = true) => {
    setState((prev) => ({
      ...prev,
      touched: { ...prev.touched, [field]: touched },
    }));
  }, []);

  const resetForm = useCallback(() => {
    setState({
      values: initialValues,
      errors: {},
      touched: {},
      dirty: {},
      isSubmitting: false,
      isValid: true,
    });
  }, [initialValues]);

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();

      const newErrors = validateForm(state.values);
      const hasErrors = Object.keys(newErrors).length > 0;

      setState((prev) => ({
        ...prev,
        errors: newErrors,
        isValid: !hasErrors,
        isSubmitting: !hasErrors,
      }));

      if (!hasErrors) {
        try {
          await onSubmit(state.values);
          setState((prev) => ({
            ...prev,
            isSubmitting: false,
          }));
        } catch (error) {
          setState((prev) => ({
            ...prev,
            isSubmitting: false,
            errors: {
              ...prev.errors,
              submit: error instanceof Error ? error.message : 'Submission failed',
            },
          }));
        }
      }
    },
    [state.values, validateForm, onSubmit],
  );

  return {
    ...state,
    setFieldValue,
    setFieldError,
    setFieldTouched,
    resetForm,
    handleSubmit,
    getFieldProps: (field: keyof T) => ({
      value: state.values[field],
      onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
        setFieldValue(field, e.target.value),
      onBlur: () => setFieldTouched(field),
    }),
  };
}

/**
 * Hook for multi-step forms
 */
export function useMultiStepForm<T extends Record<string, any>>(
  steps: (keyof T)[][],
  initialValues: T,
) {
  const [currentStep, setCurrentStep] = useState(0);
  const [values, setValues] = useState(initialValues);

  const currentFields = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  const progress = ((currentStep + 1) / steps.length) * 100;

  const nextStep = () => {
    if (!isLastStep) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const goToStep = (step: number) => {
    if (step >= 0 && step < steps.length) {
      setCurrentStep(step);
    }
  };

  return {
    currentStep,
    currentFields,
    isLastStep,
    progress,
    values,
    setValues,
    nextStep,
    prevStep,
    goToStep,
  };
}
