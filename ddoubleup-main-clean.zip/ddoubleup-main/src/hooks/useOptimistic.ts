import { useState, useCallback } from 'react';

interface OptimisticState<T> {
  data: T;
  isPending: boolean;
  error: Error | null;
}

/**
 * Hook for optimistic UI updates
 * Updates UI immediately while async operation is in progress
 */
export function useOptimistic<T>(
  initialData: T,
  asyncFn: (data: T) => Promise<T>,
) {
  const [state, setState] = useState<OptimisticState<T>>({
    data: initialData,
    isPending: false,
    error: null,
  });

  const updateOptimistic = useCallback(
    async (newData: T) => {
      setState({ data: newData, isPending: true, error: null });
      try {
        const result = await asyncFn(newData);
        setState({ data: result, isPending: false, error: null });
        return result;
      } catch (error) {
        setState({
          data: initialData,
          isPending: false,
          error: error instanceof Error ? error : new Error('Unknown error'),
        });
        throw error;
      }
    },
    [asyncFn, initialData],
  );

  return {
    ...state,
    updateOptimistic,
  };
}

/**
 * Hook for loading more data (pagination)
 */
export function useLoadMore<T>(
  initialData: T[],
  loadMoreFn: (offset: number, limit: number) => Promise<T[]>,
  pageSize = 10,
) {
  const [items, setItems] = useState(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const loadMore = useCallback(async () => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    setError(null);

    try {
      const newItems = await loadMoreFn(items.length, pageSize);
      if (newItems.length < pageSize) {
        setHasMore(false);
      }
      setItems((prev) => [...prev, ...newItems]);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to load more'));
      setHasMore(false);
    } finally {
      setIsLoading(false);
    }
  }, [items.length, isLoading, hasMore, loadMoreFn, pageSize]);

  const reset = useCallback(() => {
    setItems(initialData);
    setHasMore(true);
    setError(null);
    setIsLoading(false);
  }, [initialData]);

  return {
    items,
    isLoading,
    hasMore,
    error,
    loadMore,
    reset,
  };
}

/**
 * Hook for debounced search
 */
export function useSearch<T>(
  searchFn: (query: string) => Promise<T[]>,
  debounceMs = 300,
) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<T[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const handleSearch = useCallback(
    async (newQuery: string) => {
      setQuery(newQuery);
      setError(null);

      if (!newQuery.trim()) {
        setResults([]);
        return;
      }

      setIsLoading(true);
      const timer = setTimeout(async () => {
        try {
          const data = await searchFn(newQuery);
          setResults(data);
        } catch (err) {
          setError(err instanceof Error ? err : new Error('Search failed'));
        } finally {
          setIsLoading(false);
        }
      }, debounceMs);

      return () => clearTimeout(timer);
    },
    [searchFn, debounceMs],
  );

  return {
    query,
    results,
    isLoading,
    error,
    handleSearch,
  };
}
