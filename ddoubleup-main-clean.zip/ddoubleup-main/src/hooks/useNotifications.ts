import { useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export const useNotifications = () => {
  const { user } = useAuth();
  const permissionRef = useRef<NotificationPermission>("default");

  const requestPermission = useCallback(async () => {
    if (!("Notification" in window)) return false;
    if (Notification.permission === "granted") {
      permissionRef.current = "granted";
      return true;
    }
    if (Notification.permission === "denied") return false;
    const result = await Notification.requestPermission();
    permissionRef.current = result;
    return result === "granted";
  }, []);

  const showNotification = useCallback((title: string, body: string, onClick?: () => void) => {
    if (permissionRef.current !== "granted") return;
    if (document.hasFocus()) return; // Don't show if app is focused

    const notification = new Notification(title, {
      body,
      icon: "/placeholder.svg",
      badge: "/placeholder.svg",
      tag: "wingman-message",
    });

    if (onClick) {
      notification.onclick = () => {
        window.focus();
        onClick();
        notification.close();
      };
    }

    setTimeout(() => notification.close(), 5000);
  }, []);

  // Global listener for new messages across all rooms
  useEffect(() => {
    if (!user) return;

    requestPermission();

    // Get user's room IDs first, then listen
    const setup = async () => {
      const { data: memberships } = await supabase
        .from("chat_room_members")
        .select("room_id")
        .eq("user_id", user.id);

      if (!memberships?.length) return;

      const channel = supabase
        .channel("global-messages")
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "messages" },
          async (payload) => {
            const msg = payload.new as { sender_id: string; content: string; room_id: string };
            if (msg.sender_id === user.id) return;

            // Check if this message is in one of user's rooms
            const isMyRoom = memberships.some((m) => m.room_id === msg.room_id);
            if (!isMyRoom) return;

            // Get sender name
            const { data: profile } = await supabase
              .from("profiles")
              .select("display_name")
              .eq("user_id", msg.sender_id)
              .single();

            const senderName = profile?.display_name || "Someone";
            showNotification(
              senderName,
              msg.content.length > 100 ? msg.content.slice(0, 100) + "…" : msg.content,
              () => { window.location.hash = `/chat/${msg.room_id}`; }
            );
          }
        )
        .subscribe();

      return channel;
    };

    let channel: any;
    setup().then((ch) => { channel = ch; });

    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, [user, requestPermission, showNotification]);

  return { requestPermission };
};
