import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export const usePhotoUpload = () => {
  const { user, updateProfile } = useAuth();
  const [uploading, setUploading] = useState(false);

  const uploadAvatar = async (file: File): Promise<string | null> => {
    if (!user) return null;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/avatar.${ext}`;

      // Remove old file first (ignore errors)
      await supabase.storage.from("avatars").remove([path]);

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: file.type });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage.from("avatars").getPublicUrl(path);
      const publicUrl = `${data.publicUrl}?t=${Date.now()}`; // cache bust

      await updateProfile({ avatar_url: publicUrl });
      return publicUrl;
    } catch (err) {
      toast({ title: "Upload failed", description: "Could not upload your photo. Please try again.", variant: "destructive" });
      return null;
    } finally {
      setUploading(false);
    }
  };

  const uploadPhoto = async (file: File, slot: number): Promise<string | null> => {
    if (!user) return null;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/photo_${slot}.${ext}`;

      await supabase.storage.from("avatars").remove([path]);

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: file.type });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage.from("avatars").getPublicUrl(path);
      return `${data.publicUrl}?t=${Date.now()}`;
    } catch (err) {
      toast({ title: "Upload failed", description: "Could not upload your photo. Please try again.", variant: "destructive" });
      return null;
    } finally {
      setUploading(false);
    }
  };

  return { uploadAvatar, uploadPhoto, uploading };
};
