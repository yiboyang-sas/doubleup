import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Eye, EyeOff, Mail, Check, GraduationCap, Upload, Camera, X, Heart, Search, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

const universities = [
  "Arizona State University", "Boston College", "Boston University", "Brown University",
  "California Institute of Technology", "Carnegie Mellon University", "Clemson University",
  "Columbia University", "Cornell University", "Dartmouth College", "Duke University",
  "Emory University", "Florida Atlantic University", "Florida International University",
  "Florida State University", "Fordham University", "George Washington University",
  "Georgetown University", "Georgia Institute of Technology", "Gonzaga University",
  "Harvard University", "Howard University", "Indiana University Bloomington",
  "Iowa State University", "Johns Hopkins University", "Lehigh University",
  "Louisiana State University", "Loyola Marymount University", "Marquette University",
  "Massachusetts Institute of Technology", "Miami University (Ohio)", "Michigan State University",
  "New York University", "Northeastern University", "Northwestern University",
  "Ohio State University", "Oklahoma State University", "Oregon State University",
  "Pennsylvania State University", "Pepperdine University", "Princeton University",
  "Providence College", "Purdue University", "Rice University", "Rutgers University",
  "San Diego State University", "Santa Clara University", "Seton Hall University",
  "Southern Methodist University", "Stanford University", "Stony Brook University",
  "Syracuse University", "Temple University", "Texas A&M University",
  "Texas Christian University", "Tufts University", "Tulane University",
  "University of Alabama", "University of Arizona", "University of California, Berkeley",
  "University of California, Davis", "University of California, Irvine",
  "University of California, Los Angeles", "University of California, San Diego",
  "University of California, Santa Barbara", "University of California, Santa Cruz",
  "University of Chicago", "University of Cincinnati", "University of Colorado Boulder",
  "University of Connecticut", "University of Delaware", "University of Denver",
  "University of Florida", "University of Georgia", "University of Houston",
  "University of Illinois Urbana-Champaign", "University of Iowa", "University of Kansas",
  "University of Kentucky", "University of Maryland", "University of Massachusetts Amherst",
  "University of Miami", "University of Michigan", "University of Minnesota",
  "University of Mississippi", "University of Missouri", "University of Nebraska-Lincoln",
  "University of North Carolina at Chapel Hill", "University of Notre Dame",
  "University of Oklahoma", "University of Oregon", "University of Pennsylvania",
  "University of Pittsburgh", "University of Richmond", "University of Rochester",
  "University of San Diego", "University of South Carolina", "University of Southern California",
  "University of Tampa", "University of Tennessee", "University of Texas at Austin",
  "University of Vermont", "University of Virginia", "University of Washington",
  "University of Wisconsin-Madison", "Vanderbilt University", "Villanova University",
  "Virginia Tech", "Wake Forest University", "Washington State University",
  "Washington University in St. Louis", "West Virginia University", "Xavier University",
  "Yale University", "Other",
];

const SignUp = () => {
  const navigate = useNavigate();
  const { signUp, updateProfile } = useAuth();
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [selectedUni, setSelectedUni] = useState("");
  const [uniSearch, setUniSearch] = useState("");
  const [step, setStep] = useState<"info" | "university" | "verify" | "preference">("info");
  const [studentCardFile, setStudentCardFile] = useState<File | null>(null);
  const [studentCardPreview, setStudentCardPreview] = useState<string | null>(null);
  const [interestedIn, setInterestedIn] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [signedUp, setSignedUp] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isEdu = email.endsWith(".edu");
  const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const filteredUniversities = universities.filter((uni) =>
    uni.toLowerCase().includes(uniSearch.toLowerCase())
  );

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setStudentCardFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setStudentCardPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const removeFile = () => {
    setStudentCardFile(null);
    setStudentCardPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleCreateAccount = async () => {
    setIsLoading(true);
    const { error } = await signUp(email, password, name);
    setIsLoading(false);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      setSignedUp(true);
      setStep("university");
    }
  };

  const handleFinishSignup = async () => {
    setIsLoading(true);
    await updateProfile({
      university: selectedUni,
      interested_in: interestedIn,
      display_name: name,
    });
    setIsLoading(false);
    navigate("/setup-profile");
  };

  // Step 4: Who are you interested in?
  if (step === "preference") {
    const options = [
      { label: "Women", emoji: "👩", value: "women" },
      { label: "Men", emoji: "👨", value: "men" },
      { label: "Everyone", emoji: "✨", value: "everyone" },
    ];

    return (
      <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10">
        <button 
          onClick={() => setStep("verify")} 
          className="mb-8 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Go back to student ID verification"
        >
          <ArrowLeft className="text-foreground" size={24} />
        </button>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex-1 flex flex-col">
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-6">
            <Heart size={28} className="text-foreground" />
          </div>
          <h1 className="text-3xl font-bold font-display text-foreground mb-2">Who are you interested in?</h1>
          <p className="text-muted-foreground mb-8">This helps us show you the right duos</p>
          <div className="space-y-3 flex-1">
            {options.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setInterestedIn(opt.value)}
                className={`w-full flex items-center gap-4 px-5 py-5 rounded-2xl border transition-all text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary ${
                  interestedIn === opt.value ? "border-foreground bg-muted/50" : "border-border hover:bg-muted/30"
                }`}
                aria-pressed={interestedIn === opt.value ? "true" : "false"}
              >
                <span className="text-2xl">{opt.emoji}</span>
                <span className={`text-base font-medium ${interestedIn === opt.value ? "text-foreground" : "text-muted-foreground"}`}>
                  {opt.label}
                </span>
                {interestedIn === opt.value && (
                  <div className="ml-auto w-6 h-6 rounded-full bg-foreground flex items-center justify-center">
                    <Check size={14} className="text-background" />
                  </div>
                )}
              </button>
            ))}
          </div>
          <button
            onClick={handleFinishSignup}
            disabled={!interestedIn || isLoading}
            className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg mt-8 glow-sm active:scale-[0.98] hover:scale-[1.02] transition-transform disabled:opacity-40 disabled:hover:scale-100 disabled:cursor-not-allowed flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground"
          >
            {isLoading && <Loader2 size={18} className="animate-spin" />}
            Continue
          </button>
        </motion.div>
      </div>
    );
  }

  // Step 3: Student ID verification
  if (step === "verify") {
    return (
      <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10">
        <button 
          onClick={() => setStep("university")} 
          className="mb-8 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Go back to university selection"
        >
          <ArrowLeft className="text-foreground" size={24} />
        </button>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-6">
            <Camera size={28} className="text-foreground" />
          </div>
          <h1 className="text-3xl font-bold font-display text-foreground mb-2">Verify Your Identity</h1>
          <p className="text-muted-foreground mb-8">
            Upload a photo of your student ID card to confirm you're a current student at{" "}
            <span className="text-foreground font-medium">{selectedUni}</span>
          </p>
          <input 
            ref={fileInputRef} 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileSelect}
            aria-label="Upload student ID photo"
          />
          {!studentCardPreview ? (
            <button onClick={() => fileInputRef.current?.click()} className="w-full border-2 border-dashed border-border rounded-2xl p-10 flex flex-col items-center gap-4 hover:bg-muted/30 transition-colors">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                <Upload size={28} className="text-muted-foreground" />
              </div>
              <div className="text-center">
                <p className="text-foreground font-medium mb-1">Upload Student ID</p>
                <p className="text-xs text-muted-foreground">Tap to take a photo or choose from gallery</p>
              </div>
            </button>
          ) : (
            <div className="relative rounded-2xl overflow-hidden border border-border">
              <img src={studentCardPreview} alt="Student ID preview" className="w-full h-52 object-cover" />
              <button 
                onClick={removeFile} 
                className="absolute top-3 right-3 w-8 h-8 bg-foreground/80 rounded-full flex items-center justify-center hover:bg-foreground transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                aria-label="Remove uploaded student ID"
              >
                <X size={16} className="text-background" />
              </button>
              <div className="p-4 bg-muted/30">
                <p className="text-sm text-foreground font-medium">{studentCardFile?.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{studentCardFile && (studentCardFile.size / 1024 / 1024).toFixed(1)} MB</p>
              </div>
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-4 text-center">Your ID will be reviewed securely and deleted after verification</p>
          <button onClick={() => setStep("preference")} className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg mt-8 glow-sm active:scale-[0.98] transition-transform disabled:opacity-40" disabled={!studentCardFile}>
            Continue
          </button>
          <button onClick={() => setStep("preference")} className="w-full py-3 text-muted-foreground text-sm font-medium mt-3">
            Skip for now
          </button>
        </motion.div>
      </div>
    );
  }

  // Step 2: University selection
  if (step === "university") {
    return (
      <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10">
        <button 
          onClick={() => setStep("info")} 
          className="mb-8 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Go back to account info"
        >
          <ArrowLeft className="text-foreground" size={24} />
        </button>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-6">
            <GraduationCap size={28} className="text-foreground" />
          </div>
          <h1 className="text-3xl font-bold font-display text-foreground mb-2">Your University</h1>
          <p className="text-muted-foreground mb-6">Select the college you currently attend</p>
          <div className="relative mb-4">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={uniSearch} onChange={(e) => setUniSearch(e.target.value)} placeholder="Search universities..." className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all text-sm" />
          </div>
          <div className="space-y-2 max-h-[45vh] overflow-y-auto">
            {filteredUniversities.map((uni) => (
              <button key={uni} onClick={() => setSelectedUni(uni)} className={`w-full flex items-center justify-between px-4 py-3.5 rounded-2xl border transition-all text-left ${selectedUni === uni ? "border-foreground bg-muted/50" : "border-border bg-transparent hover:bg-muted/30"}`}>
                <span className={`text-sm font-medium ${selectedUni === uni ? "text-foreground" : "text-muted-foreground"}`}>{uni}</span>
                {selectedUni === uni && (
                  <div className="w-6 h-6 rounded-full bg-foreground flex items-center justify-center shrink-0">
                    <Check size={14} className="text-background" />
                  </div>
                )}
              </button>
            ))}
            {filteredUniversities.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">No universities found</p>}
          </div>
          <button onClick={() => setStep("verify")} className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg mt-8 glow-sm active:scale-[0.98] transition-transform disabled:opacity-40" disabled={!selectedUni}>
            Continue
          </button>
        </motion.div>
      </div>
    );
  }

  // Step 1: Basic info
  return (
    <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10 relative">
      <button 
        onClick={() => navigate(-1)} 
        className="mb-8 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        aria-label="Go back to splash screen"
      >
        <ArrowLeft className="text-foreground" size={24} />
      </button>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold font-display text-foreground mb-2">Create Account</h1>
        <p className="text-muted-foreground mb-10">Sign up with your college .edu email</p>
        <div className="space-y-5">
          <div>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Full Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Alex Johnson" className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Email</label>
            <div className="relative">
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="alex@university.edu" type="email" className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 pr-12 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all" />
              <Mail size={18} className={`absolute right-4 top-1/2 -translate-y-1/2 ${isEdu ? "text-green-600" : "text-muted-foreground"}`} />
            </div>
            {isEdu && <p className="text-xs text-green-600 mt-1.5">✓ College email detected</p>}
            {email && isValidEmail && !isEdu && <p className="text-xs text-destructive mt-1.5">A .edu email is required to sign up</p>}
            {email && !isValidEmail && <p className="text-xs text-destructive mt-1.5">Enter a valid email address</p>}
          </div>
          <div>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Password</label>
            <div className="relative">
              <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min 8 characters" type={showPass ? "text" : "password"} className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 pr-12 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all" />
              <button onClick={() => setShowPass(!showPass)} className="absolute right-4 top-1/2 -translate-y-1/2">
                {showPass ? <EyeOff size={18} className="text-muted-foreground" /> : <Eye size={18} className="text-muted-foreground" />}
              </button>
            </div>
          </div>
        </div>
        <button
          onClick={handleCreateAccount}
          disabled={!name || !isEdu || password.length < 8 || isLoading}
          className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg mt-10 glow-sm active:scale-[0.98] transition-transform disabled:opacity-40 flex items-center justify-center gap-2"
        >
          {isLoading && <Loader2 size={18} className="animate-spin" />}
          Create Account
        </button>
        <p className="text-center text-sm text-muted-foreground mt-6">
          Already have an account?{" "}
          <button onClick={() => navigate("/login")} className="text-foreground font-medium">Log in</button>
        </p>
      </motion.div>
    </div>
  );
};

export default SignUp;
