import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-dvh flex items-center justify-center bg-background px-8">
      <div className="text-center">
        <div className="w-24 h-24 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
          <span className="text-5xl">🤔</span>
        </div>
        <h1 className="mb-2 text-4xl font-bold font-display text-foreground">404</h1>
        <p className="mb-8 text-lg text-muted-foreground">Page not found</p>
        <p className="text-sm text-muted-foreground mb-8 max-w-xs">The page you're looking for doesn't exist or has been moved.</p>
        <div className="flex flex-col gap-3 max-w-xs mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-foreground text-background font-semibold active:scale-[0.98] hover:opacity-90 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground"
          >
            <ArrowLeft size={18} />
            Go Back
          </button>
          <button
            onClick={() => navigate("/")}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-2xl border border-border text-foreground font-semibold active:scale-[0.98] hover:bg-muted transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          >
            <Home size={18} />
            Go Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
