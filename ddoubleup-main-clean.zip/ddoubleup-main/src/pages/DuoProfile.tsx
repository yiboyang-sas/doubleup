import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Edit3, Sparkles, Camera, X, Check, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { usePhotoUpload } from "@/hooks/usePhotoUpload";
import { toast } from "@/hooks/use-toast";

const allInterests = [
  "Music", "Food", "Nightlife", "Sports", "Travel", "Art",
  "Greek Life", "Fitness", "Gaming", "Film", "Fashion", "Outdoors",
  "Photography", "Cooking", "Reading", "Coffee",
];

interface DuoData {
  id: string;
  prompt1: string;
  answer1: string;
  prompt2: string;
  answer2: string;
  interests: string[];
  photo1_url: string;
  photo2_url: string;
  school: string;
  user1_name: string;
  user2_name: string;
  user1_university: string;
}

const DuoProfile = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { uploadPhoto, uploading } = usePhotoUpload();
  const [loading, setLoading] = useState(true);
  const [duo, setDuo] = useState<DuoData | null>(null);
  const [editing, setEditing] = useState(false);
  const [prompt1, setPrompt1] = useState("");
  const [answer1, setAnswer1] = useState("");
  const [prompt2, setPrompt2] = useState("");
  const [answer2, setAnswer2] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [photo1, setPhoto1] = useState("");
  const [photo2, setPhoto2] = useState("");
  const [saving, setSaving] = useState(false);
  const fileInput1 = useRef<HTMLInputElement>(null);
  const fileInput2 = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadDuo = async () => {
      if (!user) return;
      setLoading(true);

      const { data: duos } = await supabase
        .from("duos")
        .select("*, user1:profiles!duos_user1_id_fkey(display_name, university), user2:profiles!duos_user2_id_fkey(display_name, university)")
        .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
        .eq("active", true)
        .limit(1);

      if (duos && duos.length > 0) {
        const d = duos[0];
        const duoData: DuoData = {
          id: d.id,
          prompt1: d.prompt1 || "Our ideal double date",
          answer1: d.answer1 || "",
          prompt2: d.prompt2 || "Our vibe",
          answer2: d.answer2 || "",
          interests: d.interests || [],
          photo1_url: d.photo1_url || "",
          photo2_url: d.photo2_url || "",
          school: d.school || (d as any).user1?.university || "",
          user1_name: (d as any).user1?.display_name || "User",
          user2_name: (d as any).user2?.display_name || "User",
          user1_university: (d as any).user1?.university || "",
        };
        setDuo(duoData);
        setPrompt1(duoData.prompt1);
        setAnswer1(duoData.answer1);
        setPrompt2(duoData.prompt2);
        setAnswer2(duoData.answer2);
        setInterests(duoData.interests);
        setPhoto1(duoData.photo1_url);
        setPhoto2(duoData.photo2_url);
      }

      setLoading(false);
    };

    loadDuo();
  }, [user]);

  const toggleInterest = (interest: string) => {
    setInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest].slice(0, 6)
    );
  };

  const handlePhotoChange = async (inputRef: React.RefObject<HTMLInputElement>, slot: 1 | 2) => {
    const file = inputRef.current?.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      if (slot === 1) setPhoto1(reader.result as string);
      else setPhoto2(reader.result as string);
    };
    reader.readAsDataURL(file);
    const url = await uploadPhoto(file, slot === 1 ? 10 : 11);
    if (url) {
      if (slot === 1) setPhoto1(url);
      else setPhoto2(url);
    }
  };

  const handleSave = async () => {
    if (!duo) return;
    setSaving(true);
    const { error } = await supabase
      .from("duos")
      .update({
        prompt1, answer1, prompt2, answer2, interests,
        photo1_url: photo1, photo2_url: photo2,
      })
      .eq("id", duo.id);
    setSaving(false);
    if (error) {
      toast({ title: "Error", description: "Failed to save changes.", variant: "destructive" });
    } else {
      toast({ title: "Saved", description: "Duo profile updated!" });
      setEditing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-dvh flex flex-col pb-24">
        <div className="px-6 pt-14 pb-2">
          <h1 className="text-2xl font-bold font-display text-foreground">Your Duo</h1>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <Loader2 size={32} className="text-muted-foreground animate-spin" />
        </div>
        <BottomNav />
      </div>
    );
  }

  if (!duo) {
    return (
      <div className="min-h-dvh flex flex-col pb-24">
        <div className="px-6 pt-14 pb-2">
          <h1 className="text-2xl font-bold font-display text-foreground">Your Duo</h1>
        </div>
        <div className="flex-1 flex items-center justify-center px-8">
          <div className="text-center">
            <Sparkles size={40} className="mx-auto text-muted-foreground/40 mb-4" />
            <h2 className="text-lg font-bold text-foreground mb-2">No duo yet</h2>
            <p className="text-sm text-muted-foreground mb-6">Invite a friend to create your duo and start matching together!</p>
            <button
              onClick={() => navigate("/invite-friend")}
              className="px-6 py-3 rounded-2xl bg-foreground text-background font-semibold active:scale-[0.98] transition-transform"
            >
              Find Your Wingmate
            </button>
          </div>
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-dvh flex flex-col pb-24">
      <div className="px-6 pt-14 pb-2 flex items-center justify-between">
        <h1 className="text-2xl font-bold font-display text-foreground">Your Duo</h1>
        <button
          onClick={() => editing ? handleSave() : setEditing(true)}
          disabled={saving}
          className={`px-4 py-2 rounded-full flex items-center gap-1.5 text-sm font-medium transition-all active:scale-[0.95] ${
            editing
              ? "bg-foreground text-background"
              : "bg-muted/50 border border-border text-foreground"
          }`}
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : editing ? <Check size={14} /> : <Edit3 size={14} />}
          {saving ? "Saving" : editing ? "Done" : "Edit"}
        </button>
      </div>

      <div className="px-6 py-4 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl overflow-hidden border border-border bg-card"
        >
          {/* Photos */}
          <div className="grid grid-cols-2 h-64 relative">
            <input ref={fileInput1} type="file" accept="image/*" className="hidden" onChange={() => handlePhotoChange(fileInput1, 1)} />
            <input ref={fileInput2} type="file" accept="image/*" className="hidden" onChange={() => handlePhotoChange(fileInput2, 2)} />
            <div className="relative">
              {photo1 ? (
                <img src={photo1} alt="Duo member 1" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center text-muted-foreground">No photo</div>
              )}
              {editing && (
                <button onClick={() => fileInput1.current?.click()} className="absolute inset-0 bg-foreground/30 flex items-center justify-center">
                  <Camera size={24} className="text-background" />
                </button>
              )}
            </div>
            <div className="relative">
              {photo2 ? (
                <img src={photo2} alt="Duo member 2" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center text-muted-foreground">No photo</div>
              )}
              {editing && (
                <button onClick={() => fileInput2.current?.click()} className="absolute inset-0 bg-foreground/30 flex items-center justify-center">
                  <Camera size={24} className="text-background" />
                </button>
              )}
            </div>
          </div>

          <div className="p-5">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold font-display text-foreground">{duo.user1_name} & {duo.user2_name}</h2>
              <div className="w-5 h-5 rounded-full bg-gradient-primary flex items-center justify-center">
                <Sparkles size={10} className="text-primary-foreground" />
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{duo.school}</p>

            {/* Prompts */}
            <div className="space-y-3">
              <div className="bg-muted/30 rounded-xl p-4">
                <p className="text-xs text-primary font-semibold uppercase tracking-wider mb-1">{prompt1}</p>
                {editing ? (
                  <textarea value={answer1} onChange={(e) => setAnswer1(e.target.value)} maxLength={150} rows={2} className="w-full bg-transparent text-sm text-foreground focus:outline-none resize-none border-b border-border pb-1" />
                ) : (
                  <p className="text-sm text-foreground">{answer1 || "Add your answer..."}</p>
                )}
              </div>
              <div className="bg-muted/30 rounded-xl p-4">
                <p className="text-xs text-secondary font-semibold uppercase tracking-wider mb-1">{prompt2}</p>
                {editing ? (
                  <textarea value={answer2} onChange={(e) => setAnswer2(e.target.value)} maxLength={150} rows={2} className="w-full bg-transparent text-sm text-foreground focus:outline-none resize-none border-b border-border pb-1" />
                ) : (
                  <p className="text-sm text-foreground">{answer2 || "Add your answer..."}</p>
                )}
              </div>
            </div>

            {/* Interests */}
            <div className="mt-4">
              {editing ? (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Interests (pick up to 6)</p>
                  <div className="flex flex-wrap gap-2">
                    {allInterests.map((interest) => (
                      <button key={interest} onClick={() => toggleInterest(interest)} className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${interests.includes(interest) ? "bg-foreground text-background" : "bg-muted/50 text-muted-foreground border border-border"}`}>
                        {interest}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {interests.map((i) => (
                    <span key={i} className="px-3 py-1.5 rounded-full bg-muted/50 text-xs text-muted-foreground border border-border">{i}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* Stats (real from DB) */}
        <DuoStats userId={user?.id} />
      </div>

      <BottomNav />
    </div>
  );
};

const DuoStats = ({ userId }: { userId: string | undefined }) => {
  const [matchCount, setMatchCount] = useState(0);
  const [likeCount, setLikeCount] = useState(0);

  useEffect(() => {
    if (!userId) return;
    const load = async () => {
      const { count: matches } = await supabase.from("matches").select("*", { count: "exact", head: true }).eq("user_id", userId).eq("is_match", true);
      const { count: likes } = await supabase.from("matches").select("*", { count: "exact", head: true }).eq("user_id", userId);
      setMatchCount(matches || 0);
      setLikeCount(likes || 0);
    };
    load();
  }, [userId]);

  return (
    <div className="grid grid-cols-3 gap-3 mt-6">
      {[
        { label: "Matches", value: String(matchCount) },
        { label: "Likes", value: String(likeCount) },
        { label: "Streak", value: "0" },
      ].map((stat) => (
        <div key={stat.label} className="bg-muted/20 border border-border rounded-2xl p-4 text-center">
          <p className="text-xl font-bold font-display text-foreground">{stat.value}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
        </div>
      ))}
    </div>
  );
};

export default DuoProfile;
