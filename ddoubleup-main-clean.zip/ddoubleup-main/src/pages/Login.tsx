import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Eye, EyeOff, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const Login = () => {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    const { error } = await signIn(email, password);
    setIsLoading(false);
    if (error) {
      toast({ title: "Login failed", description: error.message, variant: "destructive" });
    } else {
      navigate("/discover");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && email && password) handleLogin();
  };

  return (
    <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10">
      <button 
        onClick={() => navigate("/")} 
        className="mb-8 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        aria-label="Go back to splash screen"
      >
        <ArrowLeft className="text-foreground" size={24} />
      </button>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold font-display text-foreground mb-2">Welcome Back</h1>
        <p className="text-muted-foreground mb-10">Log in to your account</p>

        <div className="space-y-5">
          <div>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Email</label>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="alex@email.com"
              type="email"
              autoComplete="email"
              className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all"
              aria-label="Email address"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Password</label>
            <div className="relative">
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter password"
                type={showPass ? "text" : "password"}
                autoComplete="current-password"
                className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 pr-12 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all"
                aria-label="Password"
              />
              <button 
                onClick={() => setShowPass(!showPass)} 
                className="absolute right-4 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                aria-label={showPass ? "Hide password" : "Show password"}
              >
                {showPass ? <EyeOff size={18} className="text-muted-foreground" /> : <Eye size={18} className="text-muted-foreground" />}
              </button>
            </div>
          </div>
        </div>

        <button
          onClick={async () => {
            if (!email) {
              toast({ title: "Enter your email", description: "Type your email above, then tap Forgot password.", variant: "destructive" });
              return;
            }
            const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/login` });
            if (error) {
              toast({ title: "Error", description: error.message, variant: "destructive" });
            } else {
              toast({ title: "Check your email", description: "We sent a password reset link to your inbox." });
            }
          }}
          className="text-foreground text-sm font-medium mt-3 ml-1 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Reset forgotten password"
        >
          Forgot password?
        </button>

        <button
          onClick={handleLogin}
          disabled={!email || !password || isLoading}
          className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg mt-8 glow-sm active:scale-[0.98] hover:scale-[1.02] transition-transform disabled:opacity-40 disabled:hover:scale-100 disabled:cursor-not-allowed flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground"
          aria-label={isLoading ? "Logging in" : "Log in to account"}
        >
          {isLoading && <Loader2 size={18} className="animate-spin" />}
          Log In
        </button>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Don't have an account?{" "}
          <button onClick={() => navigate("/signup")} className="text-foreground font-medium">Sign up</button>
        </p>
      </motion.div>
    </div>
  );
};

export default Login;
