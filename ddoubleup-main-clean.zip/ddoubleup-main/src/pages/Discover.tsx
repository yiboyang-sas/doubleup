import { useState, useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform } from "framer-motion";
import { X, Heart, Star, SlidersHorizontal, GraduationCap, Check, Search, Globe, Loader2 } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { allDuos, getSchoolsFromDuos } from "@/data/duos";
import MatchCelebration from "@/components/MatchCelebration";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface DuoCard {
  id: string;
  names: string;
  school: string;
  age: string;
  prompt: string;
  answer: string;
  interests: string[];
  img1: string;
  img2: string;
  gender: "women" | "men" | "mixed";
}

const filterSchools = getSchoolsFromDuos();

const Discover = () => {
  const { profile, user } = useAuth();
  const userSchool = profile?.university || "";
  const userPreference = profile?.interested_in || "everyone";

  const [duos, setDuos] = useState<DuoCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<"left" | "right" | null>(null);
  const [showFilter, setShowFilter] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState(userSchool || "My School");
  const [schoolSearch, setSchoolSearch] = useState("");
  const [showMatch, setShowMatch] = useState(false);
  const [matchedDuo, setMatchedDuo] = useState<DuoCard | null>(null);
  const [matchRoomId, setMatchRoomId] = useState<string | null>(null);
  const [swipedIds, setSwipedIds] = useState<Set<string>>(new Set());

  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-15, 15]);
  const likeOpacity = useTransform(x, [0, 100], [0, 1]);
  const nopeOpacity = useTransform(x, [-100, 0], [1, 0]);

  // Load duos from DB, falling back to mock data
  useEffect(() => {
    const loadDuos = async () => {
      if (!user) return;
      setLoading(true);

      // Load already-swiped duo IDs
      const { data: existingMatches } = await supabase
        .from("matches")
        .select("liked_duo_id")
        .eq("user_id", user.id);
      const swiped = new Set((existingMatches || []).map((m) => m.liked_duo_id));
      setSwipedIds(swiped);

      // Try to load real duos from DB
      const { data: dbDuos } = await supabase
        .from("duos")
        .select("*, user1:profiles!duos_user1_id_fkey(display_name, avatar_url, university), user2:profiles!duos_user2_id_fkey(display_name, avatar_url, university)")
        .eq("active", true);

      if (dbDuos && dbDuos.length > 0) {
        const cards: DuoCard[] = dbDuos
          .filter((d) => d.user1_id !== user.id && d.user2_id !== user.id)
          .filter((d) => !swiped.has(d.id))
          .map((d) => ({
            id: d.id,
            names: `${(d as any).user1?.display_name || "User"} & ${(d as any).user2?.display_name || "User"}`,
            school: d.school || (d as any).user1?.university || "",
            age: "",
            prompt: d.prompt1 || "Our ideal double date",
            answer: d.answer1 || "",
            interests: d.interests || [],
            img1: d.photo1_url || (d as any).user1?.avatar_url || "",
            img2: d.photo2_url || (d as any).user2?.avatar_url || "",
            gender: "mixed" as const,
          }));
        setDuos(cards);
      } else {
        // Fallback to mock data for development / empty DB
        const mockCards: DuoCard[] = allDuos
          .filter((d) => !swiped.has(String(d.id)))
          .map((d) => ({
            id: String(d.id),
            names: d.names,
            school: d.school,
            age: d.age,
            prompt: d.prompt,
            answer: d.answer,
            interests: d.interests,
            img1: d.img1,
            img2: d.img2,
            gender: d.gender as "women" | "men",
          }));
        setDuos(mockCards);
      }

      setLoading(false);
    };

    loadDuos();
  }, [user]);

  const resolvedSchool = selectedSchool === "All Universities" ? "" : (selectedSchool === "My School" ? userSchool : selectedSchool);

  const filteredDuos = duos.filter((d) => {
    const schoolMatch = !resolvedSchool || d.school === resolvedSchool;
    const genderMatch =
      userPreference === "everyone" ||
      d.gender === "mixed" ||
      (userPreference === "women" && d.gender === "women") ||
      (userPreference === "men" && d.gender === "men");
    return schoolMatch && genderMatch;
  });

  const current = filteredDuos.length > 0
    ? filteredDuos[currentIndex % filteredDuos.length]
    : null;

  const swipe = async (dir: "left" | "right") => {
    if (!current || !user) return;

    if (dir === "right") {
      // Record like in DB
      const { error: matchError } = await supabase.from("matches").insert([{ user_id: user.id, liked_duo_id: current.id, is_match: false }]);
      if (matchError) {
        toast({ title: "Error", description: "Failed to record like. Please try again.", variant: "destructive" });
        return;
      }

      // Check if the other duo has already liked our duo (mutual match)
      // For MVP: check if there's a match record from the other duo liking us
      const { data: mutualLike } = await supabase
        .from("matches")
        .select("id")
        .eq("liked_duo_id", current.id)
        .eq("is_match", true)
        .limit(1);

      // For now, simulate mutual matching (every 3rd swipe) since real duo-to-duo
      // matching requires both duos to have swiped. Once real duos exist, replace this.
      const isMatch = swipedIds.size % 3 === 2;

      if (isMatch) {
        // Update the match record
        await supabase.from("matches").update({ is_match: true }).eq("user_id", user.id).eq("liked_duo_id", current.id);

        setMatchedDuo(current);
        // Create a chat room for this match
        const { data: room, error: roomError } = await supabase
          .from("chat_rooms")
          .insert({ name: `${profile?.display_name || "You"} & ${current.names}`, type: "match" })
          .select("id")
          .single();
        if (roomError) {
          toast({ title: "Match!", description: "Matched but couldn't create chat. Try messaging later.", variant: "destructive" });
        } else if (room) {
          await supabase.from("chat_room_members").insert({ room_id: room.id, user_id: user.id });
          setMatchRoomId(room.id);
        }
        setDirection(dir);
        setSwipedIds((prev) => new Set(prev).add(current.id));
        setTimeout(() => {
          setCurrentIndex((prev) => prev + 1);
          setDirection(null);
          setShowMatch(true);
        }, 300);
        return;
      }

      setSwipedIds((prev) => new Set(prev).add(current.id));
    }

    setDirection(dir);
    setTimeout(() => {
      setCurrentIndex((prev) => prev + 1);
      setDirection(null);
    }, 300);
  };

  const filteredSchoolList = filterSchools.filter((s) =>
    s.toLowerCase().includes(schoolSearch.toLowerCase())
  );

  const displaySchool = selectedSchool === "All Universities"
    ? "All"
    : selectedSchool === "My School"
    ? (userSchool ? userSchool.split(" ")[0] : "My School")
    : (selectedSchool ? selectedSchool.split(" ")[0] : "Filter");

  return (
    <div className="min-h-dvh flex flex-col pb-24 relative">
      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-14 pb-4">
        <h1 className="text-2xl font-bold font-display text-gradient">DoubleUp</h1>
        <button
          onClick={() => setShowFilter(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-muted/50 border border-border text-sm hover:bg-muted/70 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label={`Filter by school: ${displaySchool}`}
        >
          <SlidersHorizontal size={14} className="text-foreground" />
          <span className="text-foreground text-xs font-medium">{displaySchool}</span>
        </button>
      </div>

      {/* Card stack */}
      <div className="flex-1 relative px-4 min-h-[420px]">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <Loader2 size={32} className="mx-auto text-muted-foreground animate-spin mb-3" />
              <p className="text-sm text-muted-foreground">Finding duos for you...</p>
            </div>
          </div>
        ) : current ? (
          <AnimatePresence>
            <motion.div
              key={current.id + currentIndex}
              style={{ x, rotate }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.9}
              onDragEnd={(_, info) => {
                if (info.offset.x > 100) swipe("right");
                else if (info.offset.x < -100) swipe("left");
              }}
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{
                scale: 1,
                opacity: 1,
                x: direction === "left" ? -400 : direction === "right" ? 400 : 0,
              }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: "spring", damping: 20 }}
              className="absolute inset-x-0 top-0 bottom-0 mx-4 cursor-grab active:cursor-grabbing"
            >
              <div className="h-full rounded-3xl overflow-hidden relative bg-card border border-border flex flex-col">
                <div className="grid grid-cols-2 h-[50%] shrink-0">
                  <img src={current.img1} alt={`${current.names} photo 1`} className="w-full h-full object-cover" />
                  <img src={current.img2} alt={`${current.names} photo 2`} className="w-full h-full object-cover" />
                </div>

                <motion.div
                  style={{ opacity: likeOpacity }}
                  className="absolute top-8 left-6 px-4 py-2 border-2 border-green-500 rounded-xl rotate-[-12deg]"
                >
                  <span className="text-green-500 font-bold text-2xl">LIKE</span>
                </motion.div>
                <motion.div
                  style={{ opacity: nopeOpacity }}
                  className="absolute top-8 right-6 px-4 py-2 border-2 border-destructive rounded-xl rotate-[12deg]"
                >
                  <span className="text-destructive font-bold text-2xl">NOPE</span>
                </motion.div>

                <div className="p-4 flex-1 flex flex-col min-h-0 overflow-hidden">
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-lg font-bold font-display text-foreground truncate">{current.names}</h2>
                    {current.age && <span className="text-sm text-muted-foreground shrink-0">{current.age}</span>}
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-3">
                    <GraduationCap size={12} />
                    <span className="truncate">{current.school}</span>
                  </div>
                  <div className="bg-muted/30 rounded-xl p-3 mb-3 flex-1 min-h-0 overflow-hidden">
                    <p className="text-[10px] text-primary font-semibold uppercase tracking-wider mb-1">{current.prompt}</p>
                    <p className="text-xs text-foreground leading-relaxed line-clamp-3">{current.answer}</p>
                  </div>
                  <div className="flex gap-1.5 flex-wrap">
                    {current.interests.slice(0, 4).map((i) => (
                      <span key={i} className="px-2.5 py-0.5 rounded-full bg-muted/50 text-[10px] text-muted-foreground border border-border">{i}</span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <p className="text-lg font-bold text-foreground mb-2">No duos found</p>
              <p className="text-sm text-muted-foreground">Try a different filter</p>
              <button
                onClick={() => { setSelectedSchool("All Universities"); setCurrentIndex(0); }}
                className="mt-4 px-6 py-2.5 rounded-xl bg-foreground text-background text-sm font-medium active:scale-[0.98] transition-transform"
              >
                Show All Universities
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-center gap-6 px-8 py-4">
        <button
          onClick={() => current && swipe("left")}
          className="w-16 h-16 rounded-full border-2 border-destructive/30 flex items-center justify-center active:scale-90 hover:border-destructive/50 hover:bg-destructive/10 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-destructive"
          aria-label="Skip this duo"
          title="Skip"
        >
          <X className="text-destructive" size={28} />
        </button>
        <button
          onClick={() => current && swipe("right")}
          className="w-20 h-20 rounded-full bg-gradient-primary flex items-center justify-center glow-lg active:scale-90 hover:scale-105 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground"
          aria-label="Like this duo"
          title="Like"
        >
          <Heart className="text-primary-foreground" size={32} fill="currentColor" />
        </button>
        <button 
          onClick={() => current && swipe("right")}
          className="w-16 h-16 rounded-full border-2 border-secondary/30 flex items-center justify-center active:scale-90 hover:border-secondary/50 hover:bg-secondary/10 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Super like this duo"
          title="Super Like"
          disabled={!current}
        >
          <Star className="text-secondary" size={28} />
        </button>
      </div>

      {/* Filter Modal */}
      <AnimatePresence>
        {showFilter && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/40 z-50 flex items-end justify-center"
            onClick={() => setShowFilter(false)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-[430px] bg-background rounded-t-3xl p-6 pb-10"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold font-display text-foreground">Filter by School</h3>
                <button 
                  onClick={() => setShowFilter(false)} 
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  aria-label="Close filter modal"
                  title="Close"
                >
                  <X size={18} className="text-foreground" />
                </button>
              </div>

              <div className="relative mb-4">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={schoolSearch}
                  onChange={(e) => setSchoolSearch(e.target.value)}
                  placeholder="Search schools..."
                  className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-2.5 text-foreground placeholder:text-muted-foreground focus:outline-none text-sm"
                />
              </div>

              <div className="space-y-2 max-h-[50vh] overflow-y-auto">
                {filteredSchoolList.map((school) => (
                  <button
                    key={school}
                    onClick={() => { setSelectedSchool(school); setCurrentIndex(0); setShowFilter(false); setSchoolSearch(""); }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 rounded-2xl border transition-all text-left ${
                      selectedSchool === school
                        ? "border-foreground bg-muted/50"
                        : "border-border hover:bg-muted/30"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {school === "All Universities" && <Globe size={14} className="text-muted-foreground" />}
                      <span className={`text-sm font-medium ${selectedSchool === school ? "text-foreground" : "text-muted-foreground"}`}>
                        {school}
                      </span>
                      {school === "My School" && userSchool && (
                        <span className="text-xs text-muted-foreground">({userSchool})</span>
                      )}
                    </div>
                    {selectedSchool === school && (
                      <div className="w-6 h-6 rounded-full bg-foreground flex items-center justify-center">
                        <Check size={14} className="text-background" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Match Celebration */}
      {matchedDuo && (
        <MatchCelebration
          show={showMatch}
          onClose={() => setShowMatch(false)}
          matchNames={matchedDuo.names}
          matchImages={[matchedDuo.img1, matchedDuo.img2]}
          roomId={matchRoomId || undefined}
        />
      )}

      <BottomNav />
    </div>
  );
};

export default Discover;
