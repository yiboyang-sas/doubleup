import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Plus, Camera, Instagram, X, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { usePhotoUpload } from "@/hooks/usePhotoUpload";

const interests = [
  "Greek Life", "Sports", "Music", "Art", "Travel", "Food",
  "Nightlife", "Fitness", "Gaming", "Film", "Fashion", "Outdoors",
];

const SetupProfile = () => {
  const { updateProfile } = useAuth();
  const { uploadAvatar, uploadPhoto, uploading } = usePhotoUpload();
  const navigate = useNavigate();
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [bio, setBio] = useState("");
  const [photos, setPhotos] = useState<(string | null)[]>([null, null, null, null, null, null]);
  const [igHandle, setIgHandle] = useState("");
  const [tiktokHandle, setTiktokHandle] = useState("");
  const [showIgInput, setShowIgInput] = useState(false);
  const [showTiktokInput, setShowTiktokInput] = useState(false);
  const [uploadingSlot, setUploadingSlot] = useState<number | null>(null);
  const fileRefs = useRef<(HTMLInputElement | null)[]>([]);

  const toggleInterest = (i: string) => {
    setSelectedInterests((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i].slice(0, 5)
    );
  };

  const handlePhotoUpload = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Show preview immediately
    const reader = new FileReader();
    reader.onloadend = () => {
      setPhotos((prev) => {
        const updated = [...prev];
        updated[index] = reader.result as string;
        return updated;
      });
    };
    reader.readAsDataURL(file);

    // Upload to cloud
    setUploadingSlot(index);
    if (index === 0) {
      const url = await uploadAvatar(file);
      if (url) {
        setPhotos((prev) => { const u = [...prev]; u[0] = url; return u; });
      }
    } else {
      const url = await uploadPhoto(file, index);
      if (url) {
        setPhotos((prev) => { const u = [...prev]; u[index] = url; return u; });
      }
    }
    setUploadingSlot(null);
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => {
      const updated = [...prev];
      updated[index] = null;
      return updated;
    });
  };

  return (
    <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10">
      <button 
        onClick={() => navigate(-1)} 
        className="mb-6 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        aria-label="Go back"
      >
        <ArrowLeft className="text-foreground" size={24} />
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex-1"
      >
        <h1 className="text-3xl font-bold font-display text-foreground mb-2">
          Your Profile
        </h1>
        <p className="text-muted-foreground mb-8">Make a great first impression</p>

        {/* Photo grid */}
        <div className="grid grid-cols-3 gap-2 mb-8">
          {photos.map((photo, i) => (
            <div
              key={i}
              className={`relative rounded-2xl overflow-hidden border-2 border-dashed border-border flex items-center justify-center cursor-pointer transition-colors hover:bg-muted/40 ${
                i === 0 ? "col-span-2 row-span-2 bg-muted/30 aspect-video" : "bg-muted/20 aspect-[3/4]"
              } ${photo ? "border-solid border-border" : ""}`}
              onClick={() => !photo && fileRefs.current[i]?.click()}
            >
              <input
                ref={(el) => { fileRefs.current[i] = el; }}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handlePhotoUpload(i, e)}
                aria-label={`Upload photo slot ${i + 1}`}
              />
              {photo ? (
                <>
                  <img src={photo} alt={`Uploaded photo ${i + 1}`} className="w-full h-full object-cover absolute inset-0" />
                  {uploadingSlot === i && (
                    <div className="absolute inset-0 bg-foreground/40 flex items-center justify-center z-10">
                      <Loader2 size={20} className="text-background animate-spin" />
                    </div>
                  )}
                  <button
                    onClick={(e) => { e.stopPropagation(); removePhoto(i); }}
                    className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-foreground/70 flex items-center justify-center z-10 hover:bg-foreground transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-background"
                    aria-label={`Remove photo slot ${i + 1}`}
                    title="Remove"
                  >
                    <X size={12} className="text-background" />
                  </button>
                </>
              ) : i === 0 ? (
                <div className="flex flex-col items-center gap-2 pointer-events-none">
                  <Camera className="text-muted-foreground" size={28} />
                  <span className="text-xs text-muted-foreground">Main Photo</span>
                </div>
              ) : (
                <Plus className="text-muted-foreground pointer-events-none" size={20} />
              )}
            </div>
          ))}
        </div>

        {/* Bio */}
        <div className="mb-8">
          <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">
            Bio
          </label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Something witty about yourself..."
            maxLength={300}
            rows={3}
            className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none transition-all"
          />
          <p className="text-xs text-muted-foreground mt-1 text-right">{bio.length}/300</p>
        </div>

        {/* Interests */}
        <div className="mb-8">
          <label className="text-xs text-muted-foreground uppercase tracking-wider mb-3 block">
            Interests (pick up to 5)
          </label>
          <div className="flex flex-wrap gap-2">
            {interests.map((interest) => (
              <button
                key={interest}
                onClick={() => toggleInterest(interest)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedInterests.includes(interest)
                    ? "bg-gradient-primary text-primary-foreground glow-sm"
                    : "bg-muted/50 text-muted-foreground border border-border"
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        {/* Social links */}
        <div className="space-y-3 mb-10">
          {/* Instagram */}
          {showIgInput ? (
            <div className="flex items-center gap-2">
              <div className="flex-1 flex items-center gap-3 px-4 py-3.5 rounded-xl bg-muted/50 border border-border">
                <Instagram size={20} className="text-foreground shrink-0" />
                <input
                  value={igHandle}
                  onChange={(e) => setIgHandle(e.target.value)}
                  placeholder="@yourusername"
                  className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                  autoFocus
                />
              </div>
              <button
                onClick={() => { if (!igHandle) setShowIgInput(false); }}
                className="w-10 h-10 rounded-xl bg-foreground flex items-center justify-center shrink-0 active:scale-95 transition-transform"
              >
                {igHandle ? (
                  <span className="text-background text-xs font-bold">✓</span>
                ) : (
                  <X size={14} className="text-background" />
                )}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowIgInput(true)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-border transition-all ${
                igHandle ? "bg-muted/50" : "bg-muted/50"
              }`}
            >
              <Instagram size={20} className={igHandle ? "text-foreground" : "text-muted-foreground"} />
              <span className={`text-sm ${igHandle ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                {igHandle ? `@${igHandle}` : "Connect Instagram"}
              </span>
              {igHandle && <span className="ml-auto text-xs text-green-600">Connected ✓</span>}
            </button>
          )}

          {/* TikTok */}
          {showTiktokInput ? (
            <div className="flex items-center gap-2">
              <div className="flex-1 flex items-center gap-3 px-4 py-3.5 rounded-xl bg-muted/50 border border-border">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="shrink-0">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.18 8.18 0 0 0 3.76.92V6.24a4.83 4.83 0 0 1 0 .45Z" fill="currentColor" className="text-foreground"/>
                </svg>
                <input
                  value={tiktokHandle}
                  onChange={(e) => setTiktokHandle(e.target.value)}
                  placeholder="@yourusername"
                  className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                  autoFocus
                />
              </div>
              <button
                onClick={() => { if (!tiktokHandle) setShowTiktokInput(false); }}
                className="w-10 h-10 rounded-xl bg-foreground flex items-center justify-center shrink-0 active:scale-95 transition-transform"
              >
                {tiktokHandle ? (
                  <span className="text-background text-xs font-bold">✓</span>
                ) : (
                  <X size={14} className="text-background" />
                )}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowTiktokInput(true)}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-muted/50 border border-border"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.18 8.18 0 0 0 3.76.92V6.24a4.83 4.83 0 0 1 0 .45Z" fill="currentColor" className={tiktokHandle ? "text-foreground" : "text-muted-foreground"}/>
              </svg>
              <span className={`text-sm ${tiktokHandle ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                {tiktokHandle ? `@${tiktokHandle}` : "Connect TikTok"}
              </span>
              {tiktokHandle && <span className="ml-auto text-xs text-green-600">Connected ✓</span>}
            </button>
          )}
        </div>

        <button
          onClick={async () => {
            await updateProfile({
              bio,
              interests: selectedInterests,
              instagram: igHandle,
              tiktok: tiktokHandle,
            });
            navigate("/invite-friend");
          }}
          className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg glow-sm active:scale-[0.98] transition-transform"
        >
          Continue
        </button>
      </motion.div>
    </div>
  );
};

export default SetupProfile;
