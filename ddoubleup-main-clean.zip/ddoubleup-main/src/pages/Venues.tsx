import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, MapPin, Clock, Search, Filter, X, Users, ChevronDown } from "lucide-react";
import BottomNav from "@/components/BottomNav";

const venues = [
  {
    id: 1,
    name: "The Rooftop",
    category: "Bar",
    rating: 4.8,
    distance: "0.3 mi",
    hours: "5 PM – 2 AM",
    img: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=400&h=250&fit=crop",
    tag: "Popular for dates",
    price: "$$",
    availableTimes: ["5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM"],
  },
  {
    id: 2,
    name: "Midnight Boba",
    category: "Café",
    rating: 4.6,
    distance: "0.5 mi",
    hours: "12 PM – 1 AM",
    img: "https://images.unsplash.com/photo-1559305616-3f99cd43e353?w=400&h=250&fit=crop",
    tag: "Late night spot",
    price: "$",
    availableTimes: ["12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM", "8:00 PM", "10:00 PM"],
  },
  {
    id: 3,
    name: "Lupo Italian",
    category: "Restaurant",
    rating: 4.9,
    distance: "0.7 mi",
    hours: "6 PM – 11 PM",
    img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=250&fit=crop",
    tag: "Tables for 4",
    price: "$$$",
    availableTimes: ["6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM"],
  },
  {
    id: 4,
    name: "Neon Lounge",
    category: "Bar",
    rating: 4.5,
    distance: "0.4 mi",
    hours: "8 PM – 2 AM",
    img: "https://images.unsplash.com/photo-1566417713940-fe7c737a9ef2?w=400&h=250&fit=crop",
    tag: "Great cocktails",
    price: "$$",
    availableTimes: ["8:00 PM", "8:30 PM", "9:00 PM", "9:30 PM", "10:00 PM", "10:30 PM"],
  },
];

const categories = ["All", "Bars", "Restaurants", "Cafés", "Late Night"];
const guestOptions = [2, 3, 4, 5, 6];

const Venues = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [bookingVenue, setBookingVenue] = useState<typeof venues[0] | null>(null);
  const [selectedTime, setSelectedTime] = useState("");
  const [selectedGuests, setSelectedGuests] = useState(4);
  const [booked, setBooked] = useState(false);

  const filteredVenues = venues.filter((venue) => {
    const matchesCategory =
      activeCategory === "All" ||
      venue.category.toLowerCase().includes(activeCategory.toLowerCase().slice(0, -1));
    const matchesSearch =
      venue.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      venue.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleBook = () => {
    setBooked(true);
    setTimeout(() => {
      setBooked(false);
      setBookingVenue(null);
      setSelectedTime("");
    }, 2000);
  };

  return (
    <div className="min-h-dvh flex flex-col pb-24">
      {/* Header */}
      <div className="px-6 pt-14 pb-2">
        <h1 className="text-2xl font-bold font-display text-foreground">Venues</h1>
        <p className="text-sm text-muted-foreground mt-1">Book a spot for your double date</p>
      </div>

      {/* Search */}
      <div className="px-6 py-3">
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 bg-muted/50 border border-border rounded-xl px-4 py-3 focus-within:ring-2 focus-within:ring-foreground/20 transition-all">
            <Search size={16} className="text-muted-foreground" />
            <input
              type="text"
              placeholder="Search venues..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
              aria-label="Search for venues"
            />
          </div>
          <button 
            className="w-12 h-12 rounded-xl bg-muted/50 border border-border flex items-center justify-center hover:bg-muted transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            aria-label="Filter venues"
            title="Filter"
          >
            <Filter size={18} className="text-foreground" />
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="flex gap-2 px-6 py-2 overflow-x-auto">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full text-sm font-medium shrink-0 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary ${
              activeCategory === cat
                ? "bg-foreground text-background"
                : "bg-muted/50 text-muted-foreground border border-border hover:bg-muted/70"
            }`}
            aria-pressed={activeCategory === cat ? "true" : "false"}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Venue list */}
      <div className="px-6 py-4 space-y-4 flex-1 overflow-y-auto">
        {filteredVenues.map((venue, i) => (
          <motion.div
            key={venue.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="rounded-2xl overflow-hidden border border-border bg-card"
          >
            <div className="relative">
              <img src={venue.img} alt={venue.name} className="w-full h-36 object-cover" />
              <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-background/90 text-xs text-foreground font-medium">
                {venue.tag}
              </div>
              <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-background/90 text-xs text-foreground font-medium">
                {venue.price}
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-bold text-foreground font-display">{venue.name}</h3>
                <div className="flex items-center gap-1">
                  <Star size={12} className="text-foreground" fill="currentColor" />
                  <span className="text-sm text-foreground font-medium">{venue.rating}</span>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MapPin size={10} /> {venue.distance}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={10} /> {venue.hours}
                </span>
                <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground">
                  {venue.category}
                </span>
              </div>
              <button
                onClick={() => { setBookingVenue(venue); setSelectedTime(""); setBooked(false); }}
                className="w-full mt-3 py-2.5 rounded-xl bg-foreground text-background text-sm font-semibold active:scale-[0.98] transition-transform"
              >
                Book a Table
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Booking Modal */}
      <AnimatePresence>
        {bookingVenue && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/40 z-50 flex items-end justify-center"
            onClick={() => !booked && setBookingVenue(null)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-[430px] bg-background rounded-t-3xl p-6 pb-10"
            >
              {booked ? (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center py-8"
                >
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                    <span className="text-3xl">✓</span>
                  </div>
                  <h3 className="text-xl font-bold font-display text-foreground mb-1">Booked!</h3>
                  <p className="text-muted-foreground text-sm">
                    {bookingVenue.name} · {selectedTime} · {selectedGuests} guests
                  </p>
                </motion.div>
              ) : (
                <>
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-xl font-bold font-display text-foreground">{bookingVenue.name}</h3>
                      <p className="text-sm text-muted-foreground">{bookingVenue.category} · {bookingVenue.price}</p>
                    </div>
                    <button
                      onClick={() => setBookingVenue(null)}
                      className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                      aria-label="Close booking modal"
                      title="Close"
                    >
                      <X size={18} className="text-foreground" />
                    </button>
                  </div>

                  {/* Guest count */}
                  <div className="mb-6">
                    <label className="text-xs text-muted-foreground uppercase tracking-wider mb-3 block">
                      Number of Guests
                    </label>
                    <div className="flex gap-2">
                      {guestOptions.map((num) => (
                        <button
                          key={num}
                          onClick={() => setSelectedGuests(num)}
                          className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${
                            selectedGuests === num
                              ? "bg-foreground text-background"
                              : "bg-muted text-muted-foreground border border-border"
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Time selection */}
                  <div className="mb-6">
                    <label className="text-xs text-muted-foreground uppercase tracking-wider mb-3 block">
                      Select Time
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {bookingVenue.availableTimes.map((time) => (
                        <button
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`py-3 rounded-xl text-sm font-medium transition-all ${
                            selectedTime === time
                              ? "bg-foreground text-background"
                              : "bg-muted text-muted-foreground border border-border"
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleBook}
                    disabled={!selectedTime}
                    className="w-full py-4 rounded-2xl bg-foreground text-background font-semibold text-lg glow-sm active:scale-[0.98] transition-transform disabled:opacity-30"
                  >
                    Confirm Booking
                  </button>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
};

export default Venues;
