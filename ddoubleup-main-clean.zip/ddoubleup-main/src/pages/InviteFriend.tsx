import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Send, Link2, UserPlus, Search, Check, X, Loader2, Bell } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface SearchResult {
  user_id: string;
  display_name: string | null;
  university: string | null;
  avatar_url: string | null;
}

interface Invite {
  id: string;
  from_user_id: string;
  to_user_id: string;
  status: string;
  from_profile?: { display_name: string | null; university: string | null; avatar_url: string | null };
}

const InviteFriend = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [sending, setSending] = useState<string | null>(null);
  const [pendingInvites, setPendingInvites] = useState<Invite[]>([]);
  const [sentInvites, setSentInvites] = useState<Set<string>>(new Set());
  const [accepting, setAccepting] = useState<string | null>(null);

  // Load pending invites sent to this user
  useEffect(() => {
    if (!user) return;

    const loadInvites = async () => {
      const { data } = await supabase
        .from("duo_invites")
        .select("*")
        .eq("to_user_id", user.id)
        .eq("status", "pending");

      if (data && data.length > 0) {
        // Load sender profiles
        const senderIds = data.map((i) => i.from_user_id);
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, display_name, university, avatar_url")
          .in("user_id", senderIds);

        const profileMap = new Map((profiles || []).map((p) => [p.user_id, p]));
        const invitesWithProfiles: Invite[] = data.map((i) => ({
          ...i,
          from_profile: profileMap.get(i.from_user_id) || undefined,
        }));
        setPendingInvites(invitesWithProfiles);
      }

      // Also load sent invites to disable re-sending
      const { data: sent } = await supabase
        .from("duo_invites")
        .select("to_user_id")
        .eq("from_user_id", user.id)
        .eq("status", "pending");
      if (sent) setSentInvites(new Set(sent.map((s) => s.to_user_id)));
    };

    loadInvites();

    // Subscribe to new invites
    const channel = supabase
      .channel("duo-invites")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "duo_invites", filter: `to_user_id=eq.${user.id}` }, () => {
        loadInvites();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user]);

  const handleSearch = async () => {
    if (!searchQuery.trim() || !user) return;
    setSearching(true);
    const { data } = await supabase
      .from("profiles")
      .select("user_id, display_name, university, avatar_url")
      .neq("user_id", user.id)
      .ilike("display_name", `%${searchQuery.trim()}%`)
      .limit(10);
    setResults(data || []);
    setSearching(false);
  };

  const handleSendInvite = async (targetUserId: string) => {
    if (!user) return;
    setSending(targetUserId);
    const { error } = await supabase.from("duo_invites").insert({
      from_user_id: user.id,
      to_user_id: targetUserId,
    });
    setSending(null);
    if (error) {
      toast({ title: "Error", description: "Failed to send invite. They may already have a pending invite.", variant: "destructive" });
    } else {
      toast({ title: "Invite sent!", description: "Waiting for them to accept." });
      setSentInvites((prev) => new Set(prev).add(targetUserId));
    }
  };

  const handleAcceptInvite = async (invite: Invite) => {
    if (!user || !profile) return;
    setAccepting(invite.id);

    // Accept the invite
    const { error: updateError } = await supabase
      .from("duo_invites")
      .update({ status: "accepted" })
      .eq("id", invite.id);

    if (updateError) {
      toast({ title: "Error", description: "Failed to accept invite.", variant: "destructive" });
      setAccepting(null);
      return;
    }

    // Create the duo
    const { error: duoError } = await supabase.from("duos").insert({
      user1_id: invite.from_user_id,
      user2_id: user.id,
      school: profile.university || "",
      interests: profile.interests || [],
      photo1_url: invite.from_profile?.avatar_url || "",
      photo2_url: profile.avatar_url || "",
      prompt1: "Our ideal double date",
      answer1: "",
      prompt2: "Our vibe",
      answer2: "",
    });

    setAccepting(null);

    if (duoError) {
      toast({ title: "Error", description: "Invite accepted but failed to create duo. Please try again.", variant: "destructive" });
    } else {
      toast({ title: "Duo created!", description: "You and your wingmate are ready to match!" });
      navigate("/duo");
    }
  };

  const handleDeclineInvite = async (inviteId: string) => {
    await supabase.from("duo_invites").update({ status: "declined" }).eq("id", inviteId);
    setPendingInvites((prev) => prev.filter((i) => i.id !== inviteId));
    toast({ title: "Invite declined" });
  };

  const handleCopyLink = async () => {
    if (!user) return;
    const link = `${window.location.origin}/invite-friend?ref=${user.id}`;
    try {
      await navigator.clipboard.writeText(link);
      toast({ title: "Link copied!", description: "Share it with your friend." });
    } catch {
      toast({ title: "Couldn't copy", description: "Please copy the link manually.", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-dvh flex flex-col px-8 pt-14 pb-10 relative">
      <div className="absolute bottom-1/4 right-0 w-[200px] h-[200px] rounded-full bg-secondary/10 blur-[100px]" />

      <button onClick={() => navigate(-1)} className="mb-6">
        <ArrowLeft className="text-foreground" size={24} />
      </button>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex-1 flex flex-col">
        <div className="w-20 h-20 rounded-3xl bg-gradient-primary flex items-center justify-center mb-6 glow-sm">
          <UserPlus className="text-primary-foreground" size={36} />
        </div>

        <h1 className="text-3xl font-bold font-display text-foreground mb-2">Find Your Wingmate</h1>
        <p className="text-muted-foreground mb-8 max-w-[300px]">
          Invite a friend to form your duo. You'll match together as a pair.
        </p>

        {/* Pending invites received */}
        {pendingInvites.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Bell size={14} className="text-primary" />
              <p className="text-xs text-primary font-semibold uppercase tracking-wider">Duo Invites</p>
            </div>
            <div className="space-y-2">
              {pendingInvites.map((invite) => (
                <div key={invite.id} className="flex items-center gap-3 p-3 rounded-2xl bg-muted/20 border border-border">
                  <img
                    src={invite.from_profile?.avatar_url || `https://ui-avatars.com/api/?name=${invite.from_profile?.display_name || "U"}&background=random`}
                    alt=""
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{invite.from_profile?.display_name || "Someone"}</p>
                    <p className="text-xs text-muted-foreground truncate">{invite.from_profile?.university || ""}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDeclineInvite(invite.id)}
                      className="w-8 h-8 rounded-full border border-border flex items-center justify-center"
                    >
                      <X size={14} className="text-muted-foreground" />
                    </button>
                    <button
                      onClick={() => handleAcceptInvite(invite)}
                      disabled={accepting === invite.id}
                      className="w-8 h-8 rounded-full bg-foreground flex items-center justify-center"
                    >
                      {accepting === invite.id ? (
                        <Loader2 size={14} className="text-background animate-spin" />
                      ) : (
                        <Check size={14} className="text-background" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search */}
        <div className="mb-6">
          <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Search by Name</label>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                placeholder="Search for a friend..."
                className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={searching || !searchQuery.trim()}
              className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center shrink-0 active:scale-95 transition-transform disabled:opacity-40"
            >
              {searching ? <Loader2 size={20} className="text-primary-foreground animate-spin" /> : <Send className="text-primary-foreground" size={20} />}
            </button>
          </div>
        </div>

        {/* Search results */}
        <AnimatePresence>
          {results.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2 mb-6">
              {results.map((r) => {
                const alreadySent = sentInvites.has(r.user_id);
                return (
                  <div key={r.user_id} className="flex items-center gap-3 p-3 rounded-2xl bg-muted/20 border border-border">
                    <img
                      src={r.avatar_url || `https://ui-avatars.com/api/?name=${r.display_name || "U"}&background=random`}
                      alt=""
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{r.display_name || "User"}</p>
                      <p className="text-xs text-muted-foreground truncate">{r.university || ""}</p>
                    </div>
                    <button
                      onClick={() => handleSendInvite(r.user_id)}
                      disabled={alreadySent || sending === r.user_id}
                      className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${
                        alreadySent
                          ? "bg-muted text-muted-foreground"
                          : "bg-foreground text-background active:scale-95"
                      }`}
                    >
                      {sending === r.user_id ? <Loader2 size={14} className="animate-spin" /> : alreadySent ? "Sent" : "Invite"}
                    </button>
                  </div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="text-center text-muted-foreground text-sm my-2">or</div>

        <button
          onClick={handleCopyLink}
          className="w-full flex items-center gap-4 px-5 py-4 rounded-xl bg-muted/30 border border-border active:scale-[0.98] transition-transform"
        >
          <Link2 size={22} className="text-secondary" />
          <div className="text-left">
            <p className="text-foreground font-medium text-sm">Share Invite Link</p>
            <p className="text-muted-foreground text-xs">Send a link via text or DM</p>
          </div>
        </button>

        <div className="mt-auto pt-6">
          <button
            onClick={() => navigate("/discover")}
            className="w-full py-4 rounded-2xl border border-border text-muted-foreground font-medium active:scale-[0.98] transition-transform"
          >
            Skip for now
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default InviteFriend;
