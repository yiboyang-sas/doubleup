import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Heart } from "lucide-react";

const Splash = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center relative overflow-hidden px-8">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[300px] h-[300px] rounded-full bg-primary/20 blur-[120px]" />
      <div className="absolute bottom-1/3 left-1/3 w-[200px] h-[200px] rounded-full bg-secondary/15 blur-[100px]" />

      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", duration: 1.2, delay: 0.2 }}
        className="relative mb-8"
      >
        <div className="w-24 h-24 rounded-3xl bg-gradient-primary flex items-center justify-center glow-lg">
          <Heart className="text-primary-foreground" size={44} strokeWidth={2.5} />
        </div>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.6 }}
        className="text-5xl font-bold font-display text-gradient mb-3"
      >
        DoubleUp
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.5 }}
        className="text-muted-foreground text-center text-lg mb-16 max-w-[280px]"
      >
        Because dating is better with backup.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 0.5 }}
        className="w-full space-y-3"
      >
        <button
          onClick={() => navigate("/onboarding")}
          className="w-full py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-semibold text-lg glow-sm active:scale-[0.98] hover:scale-[1.02] transition-transform focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground"
          aria-label="Get started with DoubleUp"
        >
          Get Started
        </button>
        <button
          onClick={() => navigate("/login")}
          className="w-full py-4 rounded-2xl border border-border text-foreground font-medium text-lg active:scale-[0.98] hover:scale-[1.02] hover:bg-muted transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Log in to your account"
        >
          I already have an account
        </button>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 text-xs text-muted-foreground"
      >
        For verified college students only 🎓
      </motion.p>
    </div>
  );
};

export default Splash;
