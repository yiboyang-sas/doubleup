import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Plus, Search, X, Users, MessageCircle } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface ChatRoom {
  id: string;
  name: string | null;
  type: string;
  lastMessage: string;
  lastMessageTime: string;
  memberNames: string[];
  memberAvatars: string[];
}

const ChatList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(true);

  const loadRooms = async () => {
    if (!user) return;

    // Get rooms the user belongs to
    const { data: memberships } = await supabase
      .from("chat_room_members")
      .select("room_id")
      .eq("user_id", user.id);

    if (!memberships?.length) { setRooms([]); setLoading(false); return; }

    const roomIds = memberships.map((m) => m.room_id);

    // Get room details
    const { data: roomData } = await supabase
      .from("chat_rooms")
      .select("*")
      .in("id", roomIds);

    if (!roomData) { setLoading(false); return; }

    // Get members for all rooms
    const { data: allMembers } = await supabase
      .from("chat_room_members")
      .select("room_id, user_id, profiles(display_name, avatar_url)")
      .in("room_id", roomIds) as { data: Array<{ room_id: string; user_id: string; profiles: { display_name: string | null; avatar_url: string | null } | null }> | null };

    // Get latest message per room
    const { data: latestMessages } = await supabase
      .from("messages")
      .select("room_id, content, created_at")
      .in("room_id", roomIds)
      .order("created_at", { ascending: false });

    const lastMsgMap: Record<string, { content: string; created_at: string }> = {};
    latestMessages?.forEach((m) => {
      if (!lastMsgMap[m.room_id]) lastMsgMap[m.room_id] = m;
    });

    const result: ChatRoom[] = roomData.map((r) => {
      const roomMembers = (allMembers || []).filter((m) => m.room_id === r.id && m.user_id !== user.id);
      const lastMsg = lastMsgMap[r.id];
      return {
        id: r.id,
        name: r.name,
        type: r.type,
        lastMessage: lastMsg?.content || "No messages yet",
        lastMessageTime: lastMsg ? formatTime(lastMsg.created_at) : "",
        memberNames: roomMembers.map((m) => m.profiles?.display_name || "User"),
        memberAvatars: roomMembers.map((m) => m.profiles?.avatar_url || `https://ui-avatars.com/api/?name=${m.profiles?.display_name || "U"}&background=random`),
      };
    });

    // Sort by latest message
    result.sort((a, b) => {
      const aTime = lastMsgMap[a.id]?.created_at || "";
      const bTime = lastMsgMap[b.id]?.created_at || "";
      return bTime.localeCompare(aTime);
    });

    setRooms(result);
    setLoading(false);
  };

  useEffect(() => { loadRooms(); }, [user]);

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 86400000) return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    if (diff < 172800000) return "Yesterday";
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const filtered = rooms.filter((r) => {
    const displayName = r.name || r.memberNames.join(" & ");
    return displayName.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="min-h-dvh flex flex-col pb-24">
      {/* Header */}
      <div className="px-6 pt-14 pb-2 flex items-center justify-between">
        <h1 className="text-2xl font-bold font-display text-foreground">Messages</h1>
      </div>

      {/* Search */}
      <div className="px-6 py-2">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input 
            value={search} 
            onChange={(e) => setSearch(e.target.value)} 
            placeholder="Search messages..." 
            className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-2.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all text-sm"
            aria-label="Search chat messages"
          />
        </div>
      </div>

      {/* Chat list */}
      <div className="px-6 flex-1">
        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-sm">Loading chats...</p>
          </div>
        ) : (
          <div className="space-y-1">
            {filtered.map((room, i) => {
              const displayName = room.name || room.memberNames.join(" & ") || "Chat";
              return (
                <motion.button
                  key={room.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  onClick={() => navigate(`/chat/${room.id}`)}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-muted/30 active:scale-[0.98] transition-all text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  aria-label={`Open chat with ${room.name || room.memberNames.join(" & ")}`}
                >
                  <div className="relative shrink-0">
                    <div className="flex -space-x-2">
                      {room.memberAvatars.slice(0, 2).map((av, j) => (
                        <img key={j} src={av} alt="" className="w-12 h-12 rounded-full border-2 border-background object-cover" />
                      ))}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold truncate text-foreground">{displayName}</p>
                        {room.type === "group" && <Users size={12} className="text-muted-foreground shrink-0" />}
                      </div>
                      <span className="text-[11px] text-muted-foreground shrink-0 ml-2">{room.lastMessageTime}</span>
                    </div>
                    <p className="text-xs truncate text-muted-foreground">{room.lastMessage}</p>
                  </div>
                </motion.button>
              );
            })}

            {filtered.length === 0 && !loading && (
              <div className="text-center py-12">
                <MessageCircle size={32} className="mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground text-sm">No conversations yet</p>
                <p className="text-muted-foreground/60 text-xs mt-1">Match with duos to start chatting!</p>
              </div>
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
};

export default ChatList;
