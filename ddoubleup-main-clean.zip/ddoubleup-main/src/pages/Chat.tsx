import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Send, MapPin, Calendar, Smile, Palette, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

interface DbMessage {
  id: string;
  sender_id: string;
  content: string;
  created_at: string;
  room_id: string;
}

interface RoomMember {
  user_id: string;
  profiles: { display_name: string | null; avatar_url: string | null } | null;
}

const chatThemes = [
  { id: "default", label: "Default", bg: "bg-background", selfBubble: "bg-foreground text-background", otherBubble: "bg-muted text-foreground border border-border" },
  { id: "midnight", label: "Midnight", bg: "bg-[hsl(230,25%,12%)]", selfBubble: "bg-[hsl(260,60%,55%)] text-white", otherBubble: "bg-[hsl(230,20%,20%)] text-white border-none" },
  { id: "sunset", label: "Sunset", bg: "bg-[hsl(25,80%,95%)]", selfBubble: "bg-[hsl(15,80%,55%)] text-white", otherBubble: "bg-[hsl(30,60%,88%)] text-[hsl(15,50%,25%)] border-none" },
  { id: "ocean", label: "Ocean", bg: "bg-[hsl(200,40%,95%)]", selfBubble: "bg-[hsl(200,70%,45%)] text-white", otherBubble: "bg-[hsl(200,30%,88%)] text-[hsl(200,50%,20%)] border-none" },
  { id: "forest", label: "Forest", bg: "bg-[hsl(140,20%,94%)]", selfBubble: "bg-[hsl(150,50%,35%)] text-white", otherBubble: "bg-[hsl(140,20%,86%)] text-[hsl(150,30%,20%)] border-none" },
  { id: "rose", label: "Rosé", bg: "bg-[hsl(340,30%,95%)]", selfBubble: "bg-[hsl(340,60%,55%)] text-white", otherBubble: "bg-[hsl(340,25%,88%)] text-[hsl(340,40%,25%)] border-none" },
];

const Chat = () => {
  const navigate = useNavigate();
  const { roomId } = useParams<{ roomId: string }>();
  const { user } = useAuth();
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState<DbMessage[]>([]);
  const [members, setMembers] = useState<Record<string, { name: string; avatar: string | null }>>({});
  const [roomName, setRoomName] = useState("Chat");
  const [showThemes, setShowThemes] = useState(false);
  const [theme, setTheme] = useState(chatThemes[0]);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Load room info, members, and messages
  useEffect(() => {
    if (!roomId || !user) return;

    const loadRoom = async () => {
      // Room name
      const { data: room } = await supabase.from("chat_rooms").select("name").eq("id", roomId).single();
      if (room?.name) setRoomName(room.name);

      // Members with profiles
      const { data: memberData } = await supabase
        .from("chat_room_members")
        .select("user_id, profiles(display_name, avatar_url)")
        .eq("room_id", roomId) as { data: RoomMember[] | null };

      if (memberData) {
        const map: Record<string, { name: string; avatar: string | null }> = {};
        memberData.forEach((m) => {
          map[m.user_id] = {
            name: m.profiles?.display_name || "User",
            avatar: m.profiles?.avatar_url || null,
          };
        });
        setMembers(map);
      }

      // Messages
      const { data: msgs } = await supabase
        .from("messages")
        .select("*")
        .eq("room_id", roomId)
        .order("created_at", { ascending: true });
      if (msgs) setMessages(msgs);
    };

    loadRoom();

    // Realtime subscription
    const channel = supabase
      .channel(`room-${roomId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `room_id=eq.${roomId}` },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as DbMessage]);
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [roomId, user]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const formatTime = (iso: string) => {
    return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  };

  const sendMessage = async () => {
    if (!msg.trim() || !user || !roomId) return;
    const text = msg.trim();
    setMsg("");
    const { error } = await supabase.from("messages").insert({ content: text, sender_id: user.id, room_id: roomId });
    if (error) {
      setMsg(text);
      toast({ title: "Failed to send", description: "Your message couldn't be sent. Please try again.", variant: "destructive" });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const otherMembers = Object.entries(members).filter(([id]) => id !== user?.id);
  const headerName = roomName !== "Chat" ? roomName : otherMembers.map(([, m]) => m.name).join(" & ") || "Chat";
  const memberCount = Object.keys(members).length;

  return (
    <div className={`min-h-dvh flex flex-col ${theme.bg} transition-colors duration-300`}>
      {/* Header */}
      <div className="glass px-4 pt-14 pb-3 flex items-center gap-3 sticky top-0 z-10">
        <button 
          onClick={() => navigate("/chats")} 
          className="p-1 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Go back to chat list"
        >
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <div className="flex -space-x-3">
          {otherMembers.slice(0, 2).map(([id, m]) => (
            <img 
              key={id} 
              src={m.avatar || `https://ui-avatars.com/api/?name=${m.name}&background=random`} 
              className="w-9 h-9 rounded-full border-2 border-background object-cover" 
              alt={m.name}
            />
          ))}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-foreground font-semibold text-sm truncate">{headerName}</p>
          <p className="text-muted-foreground text-xs">{memberCount} members</p>
        </div>
        <button 
          onClick={() => setShowThemes(true)} 
          className="w-9 h-9 rounded-full bg-muted flex items-center justify-center border border-border hover:bg-muted/80 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
          aria-label="Change chat theme"
          title="Themes"
        >
          <Palette size={16} className="text-foreground" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 px-4 py-4 space-y-3 overflow-y-auto">
        {messages.map((m) => {
          const isSelf = m.sender_id === user?.id;
          const senderName = members[m.sender_id]?.name || "User";
          return (
            <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex ${isSelf ? "justify-end" : "justify-start"}`}>
              <div className="max-w-[80%]">
                {!isSelf && <p className="text-xs font-medium mb-1 ml-1 text-muted-foreground">{senderName}</p>}
                <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${isSelf ? `${theme.selfBubble} rounded-br-md` : `${theme.otherBubble} rounded-bl-md`}`}>
                  {m.content}
                </div>
                <p className={`text-[10px] text-muted-foreground mt-1 ${isSelf ? "text-right mr-1" : "ml-1"}`}>{formatTime(m.created_at)}</p>
              </div>
            </motion.div>
          );
        })}

        {messages.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-sm">No messages yet. Say hello! 👋</p>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button onClick={() => navigate("/venues")} className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-muted border border-border text-xs text-muted-foreground">
            <MapPin size={12} className="text-foreground" /> Suggest Venue
          </button>
          <button className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-muted border border-border text-xs text-muted-foreground">
            <Calendar size={12} className="text-foreground" /> Pick Time
          </button>
        </div>
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="glass px-4 py-3 safe-bottom border-t border-border">
        <div className="flex items-center gap-2">
          <button 
            className="p-2 hover:opacity-70 transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary rounded-lg"
            aria-label="Add emoji"
            title="Emoji"
          >
            <Smile size={22} className="text-muted-foreground" />
          </button>
          <input 
            value={msg} 
            onChange={(e) => setMsg(e.target.value)} 
            onKeyDown={handleKeyDown} 
            placeholder="Message..." 
            className="flex-1 bg-muted border border-border rounded-full px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all"
            aria-label="Type a message"
          />
          <button 
            onClick={sendMessage}
            disabled={!msg.trim()}
            className="w-10 h-10 rounded-full bg-foreground flex items-center justify-center active:scale-90 hover:scale-110 transition-transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground"
            aria-label="Send message"
            title="Send"
          >
            <Send size={16} className="text-background" />
          </button>
        </div>
      </div>

      {/* Theme Picker */}
      <AnimatePresence>
        {showThemes && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-foreground/40 z-50 flex items-end justify-center" onClick={() => setShowThemes(false)}>
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 25, stiffness: 300 }} onClick={(e) => e.stopPropagation()} className="w-full max-w-[430px] bg-background rounded-t-3xl p-6 pb-10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold font-display text-foreground">Chat Theme</h3>
                <button 
                  onClick={() => setShowThemes(false)} 
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  aria-label="Close theme picker"
                  title="Close"
                >
                  <X size={18} className="text-foreground" />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {chatThemes.map((t) => (
                  <button key={t.id} onClick={() => { setTheme(t); setShowThemes(false); }} className={`relative p-3 rounded-2xl border-2 transition-all ${theme.id === t.id ? "border-foreground" : "border-border"}`}>
                    <div className={`w-full h-16 rounded-xl mb-2 ${t.bg}`}>
                      <div className="p-2 space-y-1">
                        <div className={`ml-auto w-12 h-3 rounded-full ${t.selfBubble}`} />
                        <div className={`w-10 h-3 rounded-full ${t.otherBubble}`} />
                      </div>
                    </div>
                    <p className="text-xs font-medium text-foreground text-center">{t.label}</p>
                    {theme.id === t.id && (
                      <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-foreground flex items-center justify-center"><Check size={10} className="text-background" /></div>
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Chat;
