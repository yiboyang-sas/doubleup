import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowRight, GraduationCap, Users, Heart, Shield } from "lucide-react";

const steps = [
  {
    icon: GraduationCap,
    title: "Verified Students Only",
    desc: "Sign up with your .edu email. Only real college students allowed.",
    color: "from-primary to-accent",
  },
  {
    icon: Users,
    title: "Find Your Wingmate",
    desc: "Pair up with a friend to create your duo. Two is always better than one.",
    color: "from-secondary to-primary",
  },
  {
    icon: Heart,
    title: "Match as a Duo",
    desc: "Swipe on other duos. When you both match, a group chat opens instantly.",
    color: "from-accent to-secondary",
  },
  {
    icon: Shield,
    title: "Safer Together",
    desc: "Built-in accountability. Never go on a first date alone again.",
    color: "from-primary to-secondary",
  },
];

const Onboarding = () => {
  const [step, setStep] = useState(0);
  const navigate = useNavigate();
  const current = steps[step];

  const next = () => {
    if (step < steps.length - 1) setStep(step + 1);
    else navigate("/signup");
  };

  return (
    <div className="min-h-dvh flex flex-col px-8 pt-16 pb-10 relative overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[250px] h-[250px] rounded-full bg-primary/15 blur-[100px] transition-all duration-700" />

      {/* Progress */}
      <div className="flex gap-2 mb-16">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-all duration-500 ${
              i <= step ? "bg-gradient-primary" : "bg-muted"
            }`}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.35 }}
          className="flex-1 flex flex-col"
        >
          <div
            className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${current.color} flex items-center justify-center mb-10 glow-sm`}
          >
            <current.icon className="text-primary-foreground" size={36} />
          </div>

          <h2 className="text-3xl font-bold font-display text-foreground mb-4 leading-tight">
            {current.title}
          </h2>

          <p className="text-lg text-muted-foreground leading-relaxed max-w-[300px]">
            {current.desc}
          </p>
        </motion.div>
      </AnimatePresence>

      <div className="flex items-center justify-between mt-auto">
        <button
          onClick={() => navigate("/signup")}
          className="text-muted-foreground text-sm hover:text-foreground transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary rounded-lg px-2 py-1"
        >
          Skip
        </button>

        <button
          onClick={next}
          className="w-16 h-16 rounded-full bg-gradient-primary flex items-center justify-center glow-sm active:scale-95 hover:scale-105 transition-transform focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground"
          aria-label={step === steps.length - 1 ? "Go to signup" : "Next step"}
        >
          <ArrowRight className="text-primary-foreground" size={24} />
        </button>
      </div>
    </div>
  );
};

export default Onboarding;
