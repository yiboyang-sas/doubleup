import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  Settings, ChevronRight, Crown, Shield, Bell, HelpCircle, LogOut,
  ArrowLeft, X, Check, Lock, Eye, Trash2, Mail, MessageSquare,
  Heart, ChevronDown, ExternalLink, Camera, Instagram, Loader2
} from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { usePhotoUpload } from "@/hooks/usePhotoUpload";
import { toast } from "@/hooks/use-toast";

type SubPage = null | "dreampass" | "safety" | "notifications" | "help" | "editprofile" | "changepassword" | "blockedusers";

const Profile = () => {
  const navigate = useNavigate();
  const { user, profile, signOut, updateProfile } = useAuth();
  const { uploadAvatar, uploading } = usePhotoUpload();
  const [activePage, setActivePage] = useState<SubPage>(null);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);
  const [blockedUsers, setBlockedUsers] = useState<Array<{ id: string; blocked_id: string; display_name: string | null }>>([]);

  // Profile data from database
  const [profilePhoto, setProfilePhoto] = useState(profile?.avatar_url || "");
  const userName = profile?.display_name || "Set up your name";
  const userUni = profile?.university || "Select your university";
  const [igHandle, setIgHandle] = useState(profile?.instagram || "");
  const [tiktokHandle, setTiktokHandle] = useState(profile?.tiktok || "");
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Notification toggles
  const [notifMatches, setNotifMatches] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);
  const [notifEmail, setNotifEmail] = useState(false);
  const [notifMarketing, setNotifMarketing] = useState(false);

  // Safety toggles
  const [showOnline, setShowOnline] = useState(true);
  const [showDistance, setShowDistance] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const Toggle = ({ on, onToggle }: { on: boolean; onToggle: () => void }) => (
    <button
      onClick={onToggle}
      className={`w-12 h-7 rounded-full transition-colors flex items-center px-0.5 ${
        on ? "bg-foreground" : "bg-border"
      }`}
    >
      <motion.div
        animate={{ x: on ? 20 : 0 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className="w-6 h-6 rounded-full bg-background shadow-sm"
      />
    </button>
  );

  const SubPageHeader = ({ title, onBack }: { title: string; onBack: () => void }) => (
    <div className="px-6 pt-14 pb-4 flex items-center gap-4">
      <button onClick={onBack} className="p-1">
        <ArrowLeft size={22} className="text-foreground" />
      </button>
      <h1 className="text-xl font-bold font-display text-foreground">{title}</h1>
    </div>
  );

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Show preview immediately
    const reader = new FileReader();
    reader.onloadend = () => setProfilePhoto(reader.result as string);
    reader.readAsDataURL(file);
    // Upload to cloud storage
    const url = await uploadAvatar(file);
    if (url) setProfilePhoto(url);
  };

  // Edit Profile page
  if (activePage === "editprofile") {
    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Edit Profile" onBack={() => setActivePage(null)} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            {/* Profile Photo */}
            <div className="flex flex-col items-center">
              <input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
              <button onClick={() => photoInputRef.current?.click()} className="relative" disabled={uploading}>
                <div className="w-28 h-28 rounded-full p-[2px] bg-gradient-primary">
                  <img src={profilePhoto} alt="Profile" className="w-full h-full rounded-full object-cover" />
                  {uploading && (
                    <div className="absolute inset-0 rounded-full bg-foreground/40 flex items-center justify-center">
                      <Loader2 size={24} className="text-background animate-spin" />
                    </div>
                  )}
                </div>
                <div className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-foreground flex items-center justify-center border-2 border-background">
                  <Camera size={14} className="text-background" />
                </div>
              </button>
              <p className="text-xs text-muted-foreground mt-2">Tap to change photo</p>
            </div>

            {/* Social */}
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Social Accounts</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border">
                  <Instagram size={18} className="text-foreground" />
                  <input
                    value={igHandle}
                    onChange={(e) => { setIgHandle(e.target.value); updateProfile({ instagram: e.target.value }); }}
                    placeholder="Instagram username"
                    className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                  />
                  {igHandle && <span className="text-xs text-green-600">Connected</span>}
                </div>
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.18 8.18 0 0 0 3.76.92V6.24a4.83 4.83 0 0 1 0 .45Z" fill="currentColor" className="text-foreground"/>
                  </svg>
                  <input
                    value={tiktokHandle}
                    onChange={(e) => { setTiktokHandle(e.target.value); updateProfile({ tiktok: e.target.value }); }}
                    placeholder="TikTok username"
                    className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                  />
                  {tiktokHandle && <span className="text-xs text-green-600">Connected</span>}
                </div>
              </div>
            </div>

            {/* Info */}
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Info</h3>
              <div className="space-y-2">
                <div className="p-4 rounded-2xl bg-muted/20 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Name</p>
                  <p className="text-sm text-foreground font-medium">{userName}</p>
                </div>
                <div className="p-4 rounded-2xl bg-muted/20 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">University</p>
                  <p className="text-sm text-foreground font-medium">{userUni}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Dream Pass page
  if (activePage === "dreampass") {
    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Dream Pass" onBack={() => setActivePage(null)} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="w-full p-6 rounded-3xl bg-gradient-primary mb-6 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-primary-foreground/10 -translate-y-1/2 translate-x-1/2" />
              <Crown size={40} className="text-primary-foreground mx-auto mb-3" />
              <h2 className="text-2xl font-bold font-display text-primary-foreground mb-1">Dream Pass</h2>
              <p className="text-primary-foreground/80 text-sm mb-4">Unlock the full experience</p>
              <p className="text-primary-foreground text-3xl font-bold">$12.99<span className="text-lg font-normal">/mo</span></p>
            </div>
            <div className="space-y-4 mb-8">
              {[
                { title: "Unlimited Swipes", desc: "No daily limits on matching" },
                { title: "See Who Likes You", desc: "Know who's interested before you swipe" },
                { title: "Priority Matching", desc: "Your duo shows up first in the stack" },
                { title: "Boost Visibility", desc: "Get 2x more views every week" },
                { title: "Advanced Filters", desc: "Filter by interests, distance & more" },
                { title: "Read Receipts", desc: "See when your messages are read" },
              ].map((f, i) => (
                <motion.div key={f.title} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-foreground flex items-center justify-center mt-0.5 shrink-0">
                    <Check size={14} className="text-background" />
                  </div>
                  <div>
                    <p className="text-foreground font-medium text-sm">{f.title}</p>
                    <p className="text-muted-foreground text-xs">{f.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <button className="w-full py-4 rounded-2xl bg-foreground text-background font-semibold text-lg active:scale-[0.98] transition-transform">
              Start Free Trial
            </button>
            <p className="text-center text-xs text-muted-foreground mt-3">7-day free trial · Cancel anytime</p>
          </motion.div>
        </div>
      </div>
    );
  }

  // Change Password
  if (activePage === "changepassword") {
    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Change Password" onBack={() => { setActivePage("safety"); setNewPassword(""); setConfirmPassword(""); }} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            <div>
              <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">New Password</label>
              <input value={newPassword} onChange={(e) => setNewPassword(e.target.value)} type="password" placeholder="Min 8 characters" className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Confirm Password</label>
              <input value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} type="password" placeholder="Re-enter password" className="w-full bg-muted/50 border border-border rounded-xl px-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-foreground/20 transition-all" />
            </div>
            {newPassword && confirmPassword && newPassword !== confirmPassword && (
              <p className="text-xs text-destructive">Passwords don't match</p>
            )}
            <button
              onClick={async () => {
                if (newPassword.length < 8) { toast({ title: "Error", description: "Password must be at least 8 characters.", variant: "destructive" }); return; }
                if (newPassword !== confirmPassword) { toast({ title: "Error", description: "Passwords don't match.", variant: "destructive" }); return; }
                setChangingPassword(true);
                const { error } = await supabase.auth.updateUser({ password: newPassword });
                setChangingPassword(false);
                if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); }
                else { toast({ title: "Password updated" }); setActivePage("safety"); setNewPassword(""); setConfirmPassword(""); }
              }}
              disabled={!newPassword || !confirmPassword || newPassword !== confirmPassword || newPassword.length < 8 || changingPassword}
              className="w-full py-4 rounded-2xl bg-foreground text-background font-semibold text-lg active:scale-[0.98] transition-transform disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {changingPassword && <Loader2 size={18} className="animate-spin" />}
              Update Password
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  // Blocked Users
  if (activePage === "blockedusers") {
    // Load blocked users on mount
    if (blockedUsers.length === 0 && user) {
      supabase
        .from("blocked_users")
        .select("id, blocked_id")
        .eq("blocker_id", user.id)
        .then(async ({ data }) => {
          if (data && data.length > 0) {
            const ids = data.map((b) => b.blocked_id);
            const { data: profiles } = await supabase.from("profiles").select("user_id, display_name").in("user_id", ids);
            const profileMap = new Map((profiles || []).map((p) => [p.user_id, p.display_name]));
            setBlockedUsers(data.map((b) => ({ ...b, display_name: profileMap.get(b.blocked_id) || "User" })));
          }
        });
    }

    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Blocked Users" onBack={() => { setActivePage("safety"); setBlockedUsers([]); }} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {blockedUsers.length === 0 ? (
              <div className="text-center py-12">
                <Eye size={32} className="mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground text-sm">No blocked users</p>
              </div>
            ) : (
              <div className="space-y-2">
                {blockedUsers.map((b) => (
                  <div key={b.id} className="flex items-center justify-between p-4 rounded-2xl bg-muted/20 border border-border">
                    <p className="text-sm text-foreground font-medium">{b.display_name}</p>
                    <button
                      onClick={async () => {
                        await supabase.from("blocked_users").delete().eq("id", b.id);
                        setBlockedUsers((prev) => prev.filter((x) => x.id !== b.id));
                        toast({ title: "User unblocked" });
                      }}
                      className="px-3 py-1.5 rounded-full text-xs font-medium bg-muted text-foreground border border-border"
                    >
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    );
  }

  // Safety & Privacy
  if (activePage === "safety") {
    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Safety & Privacy" onBack={() => setActivePage(null)} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Visibility</h3>
              <div className="space-y-1">
                {[
                  { label: "Show Online Status", desc: "Let others see when you're active", on: showOnline, toggle: () => setShowOnline(!showOnline) },
                  { label: "Show Distance", desc: "Display how far you are from others", on: showDistance, toggle: () => setShowDistance(!showDistance) },
                  { label: "Read Receipts", desc: "Show when you've read messages", on: readReceipts, toggle: () => setReadReceipts(!readReceipts) },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-4 rounded-2xl bg-muted/20 border border-border">
                    <div>
                      <p className="text-foreground font-medium text-sm">{item.label}</p>
                      <p className="text-muted-foreground text-xs">{item.desc}</p>
                    </div>
                    <Toggle on={item.on} onToggle={item.toggle} />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Account</h3>
              <div className="space-y-1">
                <button onClick={() => setActivePage("changepassword")} className="w-full flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border text-left">
                  <Lock size={18} className="text-foreground" />
                  <div className="flex-1">
                    <p className="text-foreground font-medium text-sm">Change Password</p>
                    <p className="text-muted-foreground text-xs">Update your account password</p>
                  </div>
                  <ChevronRight size={16} className="text-muted-foreground" />
                </button>
                <button onClick={() => setActivePage("blockedusers")} className="w-full flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border text-left">
                  <Eye size={18} className="text-foreground" />
                  <div className="flex-1">
                    <p className="text-foreground font-medium text-sm">Blocked Users</p>
                    <p className="text-muted-foreground text-xs">Manage your block list</p>
                  </div>
                  <ChevronRight size={16} className="text-muted-foreground" />
                </button>
                <button onClick={() => setShowDeleteConfirm(true)} className="w-full flex items-center gap-3 p-4 rounded-2xl bg-destructive/5 border border-destructive/20 text-left">
                  <Trash2 size={18} className="text-destructive" />
                  <div className="flex-1">
                    <p className="text-destructive font-medium text-sm">Delete Account</p>
                    <p className="text-muted-foreground text-xs">Permanently remove your data</p>
                  </div>
                </button>
                {/* Delete confirmation */}
                <AnimatePresence>
                  {showDeleteConfirm && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-foreground/40 z-50 flex items-center justify-center px-8" onClick={() => setShowDeleteConfirm(false)}>
                      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="bg-background rounded-3xl p-6 w-full max-w-sm border border-border">
                        <h3 className="text-lg font-bold font-display text-destructive mb-2">Delete Account?</h3>
                        <p className="text-muted-foreground text-sm mb-6">This will permanently delete your account, duo, matches, and messages. This cannot be undone.</p>
                        <div className="flex gap-3">
                          <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-3 rounded-xl border border-border text-foreground font-medium text-sm active:scale-[0.98] transition-transform">Cancel</button>
                          <button
                            onClick={async () => {
                              // Delete profile (cascades to duos, matches, etc via FK)
                              if (user) {
                                await supabase.from("profiles").delete().eq("user_id", user.id);
                              }
                              await signOut();
                              navigate("/");
                              toast({ title: "Account deleted", description: "Your account has been removed." });
                            }}
                            className="flex-1 py-3 rounded-xl bg-destructive text-destructive-foreground font-medium text-sm active:scale-[0.98] transition-transform"
                          >
                            Delete
                          </button>
                        </div>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Notifications
  if (activePage === "notifications") {
    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Notifications" onBack={() => setActivePage(null)} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Push Notifications</h3>
              <div className="space-y-1">
                {[
                  { icon: Heart, label: "New Matches", desc: "When a duo likes you back", on: notifMatches, toggle: () => setNotifMatches(!notifMatches) },
                  { icon: MessageSquare, label: "Messages", desc: "New messages from matches", on: notifMessages, toggle: () => setNotifMessages(!notifMessages) },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-4 rounded-2xl bg-muted/20 border border-border">
                    <div className="flex items-center gap-3">
                      <item.icon size={18} className="text-foreground" />
                      <div>
                        <p className="text-foreground font-medium text-sm">{item.label}</p>
                        <p className="text-muted-foreground text-xs">{item.desc}</p>
                      </div>
                    </div>
                    <Toggle on={item.on} onToggle={item.toggle} />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Email</h3>
              <div className="space-y-1">
                {[
                  { icon: Mail, label: "Weekly Digest", desc: "Summary of your activity", on: notifEmail, toggle: () => setNotifEmail(!notifEmail) },
                  { icon: Crown, label: "Offers & Updates", desc: "Promotions and new features", on: notifMarketing, toggle: () => setNotifMarketing(!notifMarketing) },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-4 rounded-2xl bg-muted/20 border border-border">
                    <div className="flex items-center gap-3">
                      <item.icon size={18} className="text-foreground" />
                      <div>
                        <p className="text-foreground font-medium text-sm">{item.label}</p>
                        <p className="text-muted-foreground text-xs">{item.desc}</p>
                      </div>
                    </div>
                    <Toggle on={item.on} onToggle={item.toggle} />
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Help & Support
  if (activePage === "help") {
    const faqs = [
      { q: "How does matching work?", a: "You and your duo swipe together. When both duos like each other, it's a match! You can then chat and plan a double date." },
      { q: "Can I change my duo partner?", a: "Yes! Go to your Duo profile and tap Edit. You can dissolve your current duo and invite a new friend." },
      { q: "How do I verify my student status?", a: "During signup, you can use any email and upload a student ID. Our team reviews verifications within 24 hours." },
      { q: "Is my data safe?", a: "Absolutely. We encrypt all personal data and never share it with third parties. You can delete your account at any time." },
      { q: "How do I report someone?", a: "Tap the three dots on any profile or in chat to report. Our safety team reviews all reports within 12 hours." },
    ];

    return (
      <div className="min-h-dvh flex flex-col">
        <SubPageHeader title="Help & Support" onBack={() => setActivePage(null)} />
        <div className="px-6 py-4 flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">FAQ</h3>
              <div className="space-y-2">
                {faqs.map((faq, i) => (
                  <button
                    key={i}
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full text-left p-4 rounded-2xl bg-muted/20 border border-border"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-foreground font-medium text-sm pr-4">{faq.q}</p>
                      <ChevronDown size={16} className={`text-muted-foreground shrink-0 transition-transform ${openFaq === i ? "rotate-180" : ""}`} />
                    </div>
                    <AnimatePresence>
                      {openFaq === i && (
                        <motion.p initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="text-muted-foreground text-sm mt-2 overflow-hidden">
                          {faq.a}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Contact</h3>
              <div className="space-y-2">
                <button className="w-full flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border text-left">
                  <Mail size={18} className="text-foreground" />
                  <div className="flex-1">
                    <p className="text-foreground font-medium text-sm">Email Support</p>
                    <p className="text-muted-foreground text-xs">support@doubleup.app</p>
                  </div>
                  <ExternalLink size={14} className="text-muted-foreground" />
                </button>
                <button className="w-full flex items-center gap-3 p-4 rounded-2xl bg-muted/20 border border-border text-left">
                  <MessageSquare size={18} className="text-foreground" />
                  <div className="flex-1">
                    <p className="text-foreground font-medium text-sm">Live Chat</p>
                    <p className="text-muted-foreground text-xs">Available 9 AM – 9 PM EST</p>
                  </div>
                  <ExternalLink size={14} className="text-muted-foreground" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Main profile
  const menuItems = [
    { icon: Crown, label: "Dream Pass", desc: "Unlock premium features", page: "dreampass" as SubPage },
    { icon: Shield, label: "Safety & Privacy", desc: "Manage your data", page: "safety" as SubPage },
    { icon: Bell, label: "Notifications", desc: "Push & email preferences", page: "notifications" as SubPage },
    { icon: HelpCircle, label: "Help & Support", desc: "FAQ & contact us", page: "help" as SubPage },
  ];

  return (
    <div className="min-h-dvh flex flex-col pb-24">
      <div className="px-6 pt-14 pb-2 flex items-center justify-between">
        <h1 className="text-2xl font-bold font-display text-foreground">Profile</h1>
        <button
          onClick={() => setActivePage("editprofile")}
          className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center border border-border"
        >
          <Settings size={16} className="text-foreground" />
        </button>
      </div>

      <div className="px-6 py-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
          <button onClick={() => photoInputRef.current?.click()} className="relative shrink-0">
            <div className="w-20 h-20 rounded-full p-[2px] bg-gradient-primary">
              {profilePhoto ? (
                <img src={profilePhoto} alt="Profile" className="w-full h-full rounded-full object-cover" />
              ) : (
                <div className="w-full h-full rounded-full bg-muted flex items-center justify-center text-xl font-bold text-muted-foreground">
                  {userName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-foreground flex items-center justify-center border-2 border-background">
              <Camera size={10} className="text-background" />
            </div>
          </button>
          <div>
            <h2 className="text-lg font-bold text-foreground">{userName}</h2>
            <p className="text-sm text-muted-foreground">{userUni} · '26</p>
            <div className="flex items-center gap-1 mt-1">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <span className="text-xs text-green-600">Verified Student</span>
            </div>
          </div>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onClick={() => setActivePage("dreampass")}
          className="w-full p-5 rounded-2xl bg-gradient-primary mb-6 text-left glow-sm active:scale-[0.98] transition-transform relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-primary-foreground/10 -translate-y-1/2 translate-x-1/2" />
          <Crown size={24} className="text-primary-foreground mb-2" />
          <p className="text-primary-foreground font-bold font-display text-lg">Upgrade to Dream Pass</p>
          <p className="text-primary-foreground/80 text-sm mt-1">Unlimited swipes, boost visibility & more</p>
          <p className="text-primary-foreground font-bold mt-3">$12.99/mo</p>
        </motion.button>

        <div className="space-y-2">
          {menuItems.map((item, i) => (
            <motion.button
              key={item.label}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 + i * 0.05 }}
              onClick={() => setActivePage(item.page)}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-muted/20 border border-border active:scale-[0.98] transition-transform"
            >
              <item.icon size={20} className="text-foreground" />
              <div className="flex-1 text-left">
                <p className="text-foreground font-medium text-sm">{item.label}</p>
                <p className="text-muted-foreground text-xs">{item.desc}</p>
              </div>
              <ChevronRight size={16} className="text-muted-foreground" />
            </motion.button>
          ))}
        </div>

        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full flex items-center gap-4 p-4 mt-6 text-destructive active:scale-[0.98] transition-transform"
        >
          <LogOut size={20} />
          <span className="font-medium text-sm">Log Out</span>
        </button>
      </div>

      {/* Logout confirmation */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/40 z-50 flex items-center justify-center px-8"
            onClick={() => setShowLogoutConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-background rounded-3xl p-6 w-full max-w-sm border border-border"
            >
              <h3 className="text-lg font-bold font-display text-foreground mb-2">Log Out?</h3>
              <p className="text-muted-foreground text-sm mb-6">Are you sure you want to log out of your account?</p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowLogoutConfirm(false)}
                  className="flex-1 py-3 rounded-xl border border-border text-foreground font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Cancel
                </button>
                <button
                  onClick={async () => { await signOut(); navigate("/"); }}
                  className="flex-1 py-3 rounded-xl bg-destructive text-destructive-foreground font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Log Out
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
};

export default Profile;
