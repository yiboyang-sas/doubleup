
-- Fix: chat_rooms INSERT - require user to be a member after creation
DROP POLICY "Authenticated users can create rooms" ON public.chat_rooms;
CREATE POLICY "Authenticated users can create rooms" ON public.chat_rooms FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Fix: chat_room_members INSERT - only allow adding yourself or when you're already in the room
DROP POLICY "Authenticated users can add members" ON public.chat_room_members;
CREATE POLICY "Users can add members to their rooms" ON public.chat_room_members FOR INSERT TO authenticated WITH CHECK (
  auth.uid() = user_id OR
  EXISTS (SELECT 1 FROM public.chat_room_members m WHERE m.room_id = room_id AND m.user_id = auth.uid())
);
