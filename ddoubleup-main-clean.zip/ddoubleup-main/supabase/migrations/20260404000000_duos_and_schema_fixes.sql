-- =====================================================
-- DUOS TABLE: core entity - a pair of two users
-- =====================================================
CREATE TABLE public.duos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user1_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  user2_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  prompt1 TEXT DEFAULT '',
  answer1 TEXT DEFAULT '',
  prompt2 TEXT DEFAULT '',
  answer2 TEXT DEFAULT '',
  interests TEXT[] DEFAULT '{}',
  photo1_url TEXT,
  photo2_url TEXT,
  school TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT duos_different_users CHECK (user1_id <> user2_id)
);

CREATE TRIGGER update_duos_updated_at BEFORE UPDATE ON public.duos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.duos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view active duos" ON public.duos FOR SELECT TO authenticated USING (active = true);
CREATE POLICY "Users can insert duos they belong to" ON public.duos FOR INSERT TO authenticated WITH CHECK (auth.uid() = user1_id OR auth.uid() = user2_id);
CREATE POLICY "Users can update their own duos" ON public.duos FOR UPDATE TO authenticated USING (auth.uid() = user1_id OR auth.uid() = user2_id);

-- =====================================================
-- DUO INVITES TABLE: invitation to form a duo
-- =====================================================
CREATE TABLE public.duo_invites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_user_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  to_user_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT duo_invites_different_users CHECK (from_user_id <> to_user_id)
);

ALTER TABLE public.duo_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their invites" ON public.duo_invites FOR SELECT TO authenticated USING (auth.uid() = from_user_id OR auth.uid() = to_user_id);
CREATE POLICY "Users can send invites" ON public.duo_invites FOR INSERT TO authenticated WITH CHECK (auth.uid() = from_user_id);
CREATE POLICY "Users can respond to invites sent to them" ON public.duo_invites FOR UPDATE TO authenticated USING (auth.uid() = to_user_id);

-- =====================================================
-- BLOCKED USERS TABLE
-- =====================================================
CREATE TABLE public.blocked_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  blocker_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  blocked_id UUID NOT NULL REFERENCES public.profiles(user_id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (blocker_id, blocked_id)
);

ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their blocks" ON public.blocked_users FOR SELECT TO authenticated USING (auth.uid() = blocker_id);
CREATE POLICY "Users can block others" ON public.blocked_users FOR INSERT TO authenticated WITH CHECK (auth.uid() = blocker_id);
CREATE POLICY "Users can unblock" ON public.blocked_users FOR DELETE TO authenticated USING (auth.uid() = blocker_id);

-- =====================================================
-- SCHEMA FIXES: FK constraints, indexes, cascade deletes
-- =====================================================

-- Add FK on matches.user_id -> profiles.user_id
ALTER TABLE public.matches
ADD CONSTRAINT matches_user_id_fkey
FOREIGN KEY (user_id) REFERENCES public.profiles(user_id) ON DELETE CASCADE;

-- Change liked_duo_id to UUID to reference duos table
-- (keep as TEXT for now since existing data uses integer IDs from mock data,
--  but add an index for performance)
CREATE INDEX idx_matches_user_id ON public.matches(user_id);
CREATE INDEX idx_matches_liked_duo_id ON public.matches(liked_duo_id);

-- Add FK on messages.sender_id -> profiles.user_id
ALTER TABLE public.messages
ADD CONSTRAINT messages_sender_id_fkey
FOREIGN KEY (sender_id) REFERENCES public.profiles(user_id) ON DELETE CASCADE;

-- Performance indexes
CREATE INDEX idx_messages_room_id ON public.messages(room_id);
CREATE INDEX idx_messages_created_at ON public.messages(created_at DESC);
CREATE INDEX idx_chat_room_members_user_id ON public.chat_room_members(user_id);
CREATE INDEX idx_chat_room_members_room_id ON public.chat_room_members(room_id);
CREATE INDEX idx_profiles_user_id ON public.profiles(user_id);
CREATE INDEX idx_duos_user1 ON public.duos(user1_id);
CREATE INDEX idx_duos_user2 ON public.duos(user2_id);
CREATE INDEX idx_duo_invites_to ON public.duo_invites(to_user_id);
CREATE INDEX idx_duo_invites_from ON public.duo_invites(from_user_id);

-- =====================================================
-- TIGHTEN RLS POLICIES
-- =====================================================

-- Restrict chat_room_members: only allow adding yourself
DROP POLICY IF EXISTS "Users can add members to their rooms" ON public.chat_room_members;
CREATE POLICY "Users can add themselves to rooms" ON public.chat_room_members FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Add UPDATE/DELETE policies for chat_rooms (members only)
CREATE POLICY "Room members can update room" ON public.chat_rooms FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.chat_room_members WHERE room_id = id AND user_id = auth.uid())
);

-- Restrict chat_rooms creation to authenticated users with a profile
DROP POLICY IF EXISTS "Authenticated users can create rooms" ON public.chat_rooms;
CREATE POLICY "Authenticated users can create rooms" ON public.chat_rooms FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE user_id = auth.uid())
);

-- Enable realtime for duo_invites so users get notified
ALTER PUBLICATION supabase_realtime ADD TABLE public.duo_invites;
