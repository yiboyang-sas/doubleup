-- Add foreign key from chat_room_members.user_id to profiles.user_id for join support
ALTER TABLE public.chat_room_members
ADD CONSTRAINT chat_room_members_user_id_fkey
FOREIGN KEY (user_id) REFERENCES public.profiles(user_id) ON DELETE CASCADE;